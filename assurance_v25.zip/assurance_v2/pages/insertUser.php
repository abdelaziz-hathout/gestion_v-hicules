<?php
 require_once("identifier.php");

require_once('connexiondb.php');
$login=isset($_POST['login'])?$_POST['login']:""; 
 $pwd=isset($_POST['pwd'])?$_POST['pwd']:"";
 $email=isset($_POST['email'])?$_POST['email']:"";
 $type=isset($_POST['type'])?$_POST['type']:0;
 $etat=isset($_POST['etat'])?$_POST['etat']:0;
  $sql="INSERT INTO users(login,pwd,email,type,etat) values('$login','$pwd','$email','$type','$etat')";
$res=mysqli_query($conn,$sql);
if($res){
	echo"donnees inserees.";
}
else {
	echo"erreursj";
}
  
?>