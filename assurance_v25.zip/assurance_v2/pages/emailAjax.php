<?php 

require_once("identifier.php");
require_once "connexiondb.php";
 $cin=strtoupper(isset($_POST['cin'] ) ?$_POST['cin']:"");
 $email=strtoupper(isset($_POST['mail'] ) ?$_POST['mail']:"");

 if(strlen($email)>0 or strlen($cin)>0){
 $req="SELECT * from clients where UPPER(clients.mail)='$email'";
 $req1="SELECT * from clients where UPPER(clients.cin)='$cin' ";
 $res=mysqli_query($conn,$req);
 $res1=mysqli_query($conn,$req1);
 	if(mysqli_num_rows($res)>0 and mysqli_num_rows($res1)>0 and $email!='' and $cin !=''){
  echo'<span style="color:black;background:#FA9B9B;">cin et email sont deja existe!</span>';
    echo'<script> $("#cinClt,#mailClt").css({
 	border:"5px solid red"
 	});
 	 </script>';
 	 
 	echo'<script>$("#save01").attr("disabled","");</script>';
 	}
 else if((mysqli_num_rows($res)>0 and $email!='') or (mysqli_num_rows($res1)>0)and $cin!=''){
 if(mysqli_num_rows($res)>0 and $email!=''){
 	echo'<span style="color:black;background:#FA9B9B;">email est deja existe!</span>';
    echo'<script> $("#mailClt").css({
 	border:"5px solid red"
 	});$("#cinClt").css({
 	border:"none"
 	});
 	 </script>';
 	echo'<script>$("#save01").attr("disabled","");</script>';}
 if(mysqli_num_rows($res1)>0 and $cin!=''){
 	 echo'<span style="color:black;background:#FA9B9B;">cin est deja existe!</span>';
    echo'<script> $("#cinClt").css({
 	border:"5px solid red"
 	}); $("#mailClt").css({
 	border:"none"
 	});
 	 </script>';
 	echo'<script>$("#save01").attr("disabled","");</script>';}
 	 
 	

}
else {
	 echo'<script>$("#mailClt,#cinClt").css({
 	border:"none"
 	}); </script>';
 	echo'<script>$("#save01").removeAttr("disabled");</script>';
}
}
 ?>