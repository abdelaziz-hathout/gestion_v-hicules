
<!DOCTYPE html>
<html>
<head>
	<title>AR Assurance</title>
	<link rel="stylesheet" type="text/css" href="../styles/bootstrap/css/bootstrap.min.css">
  	<link rel="stylesheet" type="text/css" href="../styles/font-awesome/css/font-awesome.min.css">
  	<link rel="stylesheet" type="text/css" href="../styles/css/style2.css">
  	<link rel='shortcut icon' href='../images/AssuranceAR1.png' />
  	<script src="../styles/bootstrap/js/bootstrap.bundle.min.js" ></script>
  	<script src="../js/jquery.js"></script>
  	<script src="../js/js3.js"></script>
</head>
<body>
	<div class="container col-lg-6 col-md-11 col-sm-11">
		<br/>
		<br/>
		<br/>
		<br/>
		<center> <b id="login-name">Forget password </b> </center>
         
			<div  id="login1">  

				<form  method="post" actio="forgetPassword.php"id="sub3">

					<div class="form-group">
						<label class="user"> E-mail </label>
						<div class="input-group">

							<span class="input-group-addon" id="iconn"> <i class="fa fa-envelope fa-3x"></i></span>
							<input type="email" class="form-control ipt" id="user1" name="email" placeholder="Taper votre email" autocomplete="off"  required>
						</div>

						<center><div class="erru"></div></center>
					</div>

					<div class="form-group">
						
						<div class="errp"> 
							<?php 
							if(isset($_POST['submit'])){
								require ("initPassword.php");
							}

							?>

						</div>
					</div>

					<div class="form-group">
						<button type="submit" name="submit"class="btn btn-outline-success ipt"id="log"><i class="fa fa-send"></i> envoyer</button>

					</div>&nbsp &nbsp
					<a id="fp" href="login2.php" ><center>retour</center> </a>
				</form>
		</div>
	</div>
</body>
</html>