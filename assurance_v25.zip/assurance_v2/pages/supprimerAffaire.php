
<?php
  
  require_once("identifier.php");

                     require_once('connexiondb.php');
                     $id=isset($_GET['id'])?$_GET['id']:0;
                     
                     $req1="SELECT * from fractions,reglement where (fractions.id=reglement.fraction) and fractions.affaire='$id'";
                     $res1=mysqli_query($conn,$req1);
                     if(mysqli_num_rows($res1)<=0){
                     
                     $req2="DELETE from fractions where affaire='$id'";
                     $res2=mysqli_query($conn,$req2);
                     $requete="delete from affaires  WHERE id='$id'";
                     $resultat=mysqli_query($conn,$requete);
                     if($resultat){
                     echo'affaire est supprimee.'; 
                   }
                   }
                   else echo'affaire a des reglements.';

             header("location:affaires.php");
                      
?>