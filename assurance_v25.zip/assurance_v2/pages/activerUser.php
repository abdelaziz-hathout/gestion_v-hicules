<?php
 require_once("identifier.php");
  
require_once('connexiondb.php');
 $id=isset($_GET['id'])?$_GET['id']:0;
 $etat=isset($_GET['etat'])?$_GET['etat']:0; 

 if($etat==1)
 	$newEtat=0;
 else 
 	$newEtat=1;

  $sql="UPDATE users SET etat='$newEtat' where id='$id' ";
$res=mysqli_query($conn,$sql);
if($res){
	header('location:utilisateur.php');
}
else {
	echo"erreur de modification";
}

?>