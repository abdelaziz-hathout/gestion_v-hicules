<?php
require_once("identifier.php");
?>
<!DOCTYPE HTML>
<html>
<head>

  <meta charset="utf-8">
  <title>Nouvelle fraction</title>
 <?php require("styleLinks.php");?>

</head>
<body>

 <?php 
 require_once("identifier.php");

 include("header.php"); ?>


 <div class="container col-lg-4 col-lg-offset-3 col-md-8 col-md-offset-2">



   <div class="card  "> 

    <div class="card-header bg-primary">Saisir les données du fraction</div>
    
    <div class="card-body text-info bg-light">


      <form method="post" action="insertFraction.php" class="form">
       <div class="form-group ">
         <label for="affaire">affaire:</label>
         <input type="number "
         name="affaire" required
         placeholder="Taper une affaire" 
         class="form-control"/>

         <label for="mantant">montant:</label>
         <input type="number "
         name="mantant"  required
         placeholder="Taper un mantant" 
         class="form-control"/><br>

         <label for="date_effet">date_effet:</label>
         <input type="date"
         name="date_effet"  required
         placeholder="Taper un date_effet" 
         class="form-control"/><br>
         <label for="date_reg">date_reg:</label>
         <input type="date"
         name="date_reg"  required
         placeholder="Taper un date_reg" 
         class="form-control"/><br>
         <label for="solde">solde:</label>
         <input type="number "
         name="solde"  required
         placeholder="Taper un solde" 
         class="form-control"/><br>
        
         <button type="reset" name="reset" class="btn btn-danger">
          <span class="fa fa-remove"></span> 
          reset
        </button>
        <button type="submit" name="save" class="btn btn-success" value="save">
          <span class="fa fa-save"></span> 
          Save
        </button> &nbsp &nbsp
        <a href="javaScript:history.back()" id="rt">retour </a>
       
      </div>
    </form>
  </div>
</div>

</div>


</body>

<footer>

  <?php
  include("footer.php");
  ?>
</footer>

</html> 