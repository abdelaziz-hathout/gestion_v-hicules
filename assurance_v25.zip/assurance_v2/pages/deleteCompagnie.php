<?php
 require_once("identifier.php");


require_once('connexiondb.php');
 $id=isset($_GET['id'])?$_GET['id']:0;
  $sql="DELETE FROM compagnies where id='$id' ";
$res=mysqli_query($conn,$sql);
if($res){
	echo"les donnees sont supprimees.";
	header("location:compagnie.php");
}
else {
	echo"erreur ";
}

?>