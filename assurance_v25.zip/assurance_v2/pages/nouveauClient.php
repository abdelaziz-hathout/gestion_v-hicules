<?php
require_once("identifier.php");
?>
<!DOCTYPE HTML>
<html>
<head>

  <meta charset="utf-8">
  <title>Nouveau client</title>
 <?php require("styleLinks.php");?>

</head>
<body>

 <?php 
 require_once("identifier.php");

 include("header.php"); ?>


 <div class="container  col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2">



   <div class="card  margetop60"> 
    <div class="card-header bg-primary">Saisir les données du client</div>
    <div class="card-body text-info bg-light">
      <form method="post" action="insertClients.php" class="form" id="nClt">
       <div class="form-group">
        <div id="cltErr" ></div>
         <label for="nom">Nom:
         <input type="text" autocomplete="off" minlength="3" maxlength="30" pattern="^[a-zA-Z\s_]{3,}$" 
         name="nom" required 
         class="form-control "/></label>

         <label for="cin">Cin:&nbsp &nbsp<span id="cinErr"></span>
         <input type="text" autocomplete="off" id="cinClt"
         name="cin" required minlength="5" maxlength="10" pattern="^([a-zA-Z0-9]){5,10}" 
         class="form-control"/></label>

         <label for="contact">Contact:
         <input type="text" autocomplete="off" 
         name="contact"  
         class="form-control"/></label>

         <label for="adresse">Adresse:
         <input type="text" autocomplete="off" minlength="3" maxlength="500" pattern="([\w\s-]){3,}" 
         name="adresse"    
         class="form-control"/></label>

         <label for="ville">Ville:
         <input type="text" autocomplete="off" minlength="3" maxlength="50"pattern="^([a-zA-Z_ \s -]){3,}$"
         name="ville"     
         class="form-control"/></label>
         <label for="cp">Cp:
         <input type="text" autocomplete="off" minlength="3" maxlength="20"pattern="^([\d]){3,}"
         name="cp"      
         class="form-control"/></label>
         <label for="tel">Tel:
         <input type="text" autocomplete="off" minlength="9" maxlength="15" pattern="^(0|\+([0-9]){2,3})([0-9]){8,9}$" 
         name="tel"     
         class="form-control"/></label>
         <label for="fax">Fax:
         <input type="text" autocomplete="off"  minlength="9" maxlength="15"pattern="^(0|\+([0-9]){2,3})([0-9]){8,9}$" 
         name="fax"    
         class="form-control"/></label>
         <label for="ice">Ice:
         <input type="text" autocomplete="off" minlength="3" maxlength="50"
         name="ice"pattern="^([a-zA-Z0-9]){3,}" 
         class="form-control"/></label>
         <label for="mail">Email:&nbsp &nbsp<span id="emailErr"></span>
         <input type="text" autocomplete="off"  minlength="11" maxlength="50" pattern="^([a-zA-Z]){1}([\w.])*(@gmail\.com){1}$" id="mailClt"
         name="mail"      
         class="form-control"/></label>
         <label for="activite">Activite:
         <input type="text "minlength="3" pattern="^([a-zA-Z\s_-]){3,}"
         name="activite"     
         class="form-control"/></label>
         <label for="ops">Obs:
         <input type="text" autocomplete="off" minlength="3"pattern="^([a-zA-Z]){3,}([\w\s:_])*"
         name="obs"       
         placeholder="observation" 
         class="form-control"/></label>
         <label for="pays">Pays:
         <input type="text "minlength="3" maxlength="50"pattern="^([a-zA-Z_ \s -]){3,}$"
         name="pays"  id="pays"    
         class="form-control"/></label>
         <label for="mandataire">Mandataire:
         <select  name="mandataire" class="form-control"  id="mandataire">
         <option value="0" selected></option>
         <?php  require_once "connexiondb.php";
         $req="select * from mandataires";
         $res=mysqli_query($conn,$req);
         while($mandataires=mysqli_fetch_assoc($res)){?>
         <option value="<?php echo $mandataires["id"]?>" > <?php echo  $mandataires['nom'].' : '.$mandataires['cin']?></option>
        <?php }?>
        </select>
        </label><br>
        <button type="reset" name="reset" class="btn btn-danger" value="save">
          <span class="fa fa-remove"></span> 
          reset
        </button>
        <button type="submit" name="save" class="btn btn-success" value="save" id="save01">
          <span class="fa fa-save"></span> 
          Save
        </button>&nbsp &nbsp
        <a href="javaScript:history.back()" id="rt">retour </a>
      </div>
    </form>
    
  </div>
</div>

</div>


</body>

<footer>

  <?php
  include("footer.php");
  ?>
</footer>

</html> 