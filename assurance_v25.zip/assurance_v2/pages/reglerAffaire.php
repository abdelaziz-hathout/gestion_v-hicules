
<?php

require_once("identifier.php");

require_once('connexiondb.php');
$id=isset($_GET['id'])?$_GET['id']:0;
$requete="select * from affaires where id=$id";

$resultat=mysqli_query($conn,$requete);
$affaire=mysqli_fetch_array($resultat);

$cmp=$affaire['compagnie'] ;
  $clt=$affaire['client'];
  $rsq=$affaire['risque'];
  $op=$affaire['op'];
  $req="SELECT compagnies.mail as'mail',compagnies.nom as'nomCmp', clients.cin as'cin', clients.nom as'nomClt', risque.matricule as'mat' from affaires,compagnies, clients, risque where (clients.id=affaires.client and  risque.id=affaires.risque and compagnies.id=affaires.compagnie) and (compagnies.id=$cmp and clients.id=$clt and risque.id=$rsq ) ";
  $res=mysqli_query($conn,$req);
  $aff=mysqli_fetch_assoc($res); 
$requete2="select * from fractions where affaire=$id";

$resultatFraction=mysqli_query($conn,$requete2);



$datea=$affaire['datea'];
$timea=$affaire['timea'] ;
$compagnie=$affaire['compagnie'];
$police=$affaire['police'] ;

$type=$affaire['type'];
$ferme=$affaire['ferme'];
$client=$affaire['client'];
$risque= $affaire['risque'];
$production= $affaire['production'];

$duree=$affaire['duree'] ;
$datei= $affaire['datei'];
$datef= $affaire['datef'];
$solde= $affaire['solde'] ;
$obs=$affaire['obs'];
$etat=$affaire['etat'];
$op=$affaire['op'];
$nbrFractions=$affaire['nbrFractions'];
$numAttest=$affaire['numAttest'];



?>

<!DOCTYPE HTML>
 <html>
    <head>
      <meta charset="utf-8">
      <title>Reglement d'une Affaire</title>
     <?php require("styleLinks.php");?>
    
    </head>
       <body>
  
           <?php   include("header.php"); ?>

           <div class="container  col-lg-11 col-md-12 col-sm-12">
            <div class="card ">
  <div class="row">
        <div class="col col-md-6">
          <div class="card-header bg-success text-white" > <center><a href="affaires.php?client=<?php echo $affaire["police"] ?>" style="color:orange; font-size: 23px;"> Affaiare: </a></center></div>  <br>
        <div class="card-body text-info bg-light">
            
      <form method="post" action="updateAffaire.php" class="form">
          <div id="hd">
           <table class="table table-responsive table-bordered " >
           
         <div class="form-group">
           <tr >
            <td >
         <label >clients: 
         <input type="text"  readonly 
         name="clients" 
         class="form-control " value="<?php echo $aff['nomClt'].' : '.$aff['cin'] ?>" /></label>
         </td>
         <td>
         <label >compagnie:
         <input type="text"  readonly
         name="compagnie"  value="<?php  echo $aff['nomCmp'].' : '.$aff['mail'] ?>" 
         class="form-control"/></label>
         </td>
         <td>
         <label >police:  
         <input type="text" readonly
         name="police" required
         placeholder="Taper un police" value="<?php  echo $affaire['police'] ?>"
         class="form-control" id="police"/></label>
         </td>
         </tr>
         <tr >
           <td >
         <label >datea: 
         <input type="date" readonly
         name="datea" required 
         placeholder="date"
         class="form-control " value="<?php echo $affaire['datea'] ?>" /></label>
         </td>
         <td>
         <label >time:
         <input type="time" readonly 
         name="timea"  required value="<?php echo $affaire['timea']  ?>" 
         placeholder="time" 
         class="form-control"/></label>
         </td>
         <td>
         <label >numAttest:  
         <input type="text" readonly
         name="numAttest"  value="<?php  echo $affaire['numAttest'] ?>"
         class="form-control" id="numAttest"/></label>
         </td>
         </tr>

         <tr>
           <td>
            type: 
            <select name="type"class="form-control" id="select3"  disabled >
                <option value="1" <?php if($affaire['type']==1) echo 'selected'; ?>>auto</option>
                <option value="0" <?php if($affaire['type']==0) echo 'selected'; ?>>moto</option>
            </select>
        </td>
        <td>
            ferme:   
            <select name="ferme"class="form-control" id="select4" disabled >
                <option value="0" <?php if($affaire['ferme']==0) echo 'selected'; ?> >ferme</option>
                <option value="1"<?php if($affaire['ferme']==1) echo 'selected'; ?> >ouvert</option>
            </select>
        </td>
        <td>
            matricule:  
            <select name="risque"class="form-control" id="select5"  disabled>
             <?php  require_once "connexiondb.php";
             $req2="select * from risque ";
             $res2=mysqli_query($conn,$req2);
             while($risque=mysqli_fetch_assoc($res2)){?>
                <option value="<?php echo $risque['id']?>" <?php if($affaire['risque']==$risque['id']) echo 'selected';  ?>><?php echo $risque['matricule']?></option>
            <?php }?>
        </select>
    </td>
</tr>

          <tr>
        <td>
        <label for="obs">obs:  
        <input type="text"  readonly
        name="obs"  value="<?php echo $affaire['obs'] ?>" id="op"
        placeholder="Taper un obs" 
        class="form-control"/></label>
         </td>
        <td>
        <label for="fraction">nbr de fractions:  
        <input type="number" readonly 
        name="nbrFractions"  value="<?php echo $affaire['nbrFractions'] ?>"
        placeholder="Taper un fraction" 
        class="form-control"/></label>
        </td>
        <td>
        <label for="op">op:  
        <input type="text "  readonly
        name="op" value="<?php echo $op?>" 
        placeholder="Taper un op" 
        class="form-control"/></label>
        </td>
         </tr>
          <tr>
         <td>
        duree: 
         <select name="  &nbsp &nbspduree" class="form-control  date1" id="duree" disabled  >
             <option value="1" <?php  if($affaire['duree']==1) echo'selected';?>>1 mois</option>
             <option value="3" <?php if($affaire['duree']==3) echo'selected'; ?>>3 mois</option>
             <option value="6"<?php  if($affaire['duree']==6) echo'selected';?>>6 mois</option>
             <option value="12" <?php  if($affaire['duree']==12) echo'selected';?>>12 mois</option>
             
         </select>
         </td>
         <td>
        <label for="datei">datei:  
        <input type="date"  readonly
        name="datei" id="datei" required
        placeholder="Taper un datei" min="<?php echo $affaire['datei']?>" value="<?php echo $affaire['datei'] ?>" 
        class="form-control date1"/></label>
        </td>
         <td>
        <label for="datef">datef:  
        <input type="date" 
        name="datef" readonly id="datef"value="<?php echo $affaire['datef'] ?>"
        placeholder="datef" 
        class="form-control"/></label>
        </td>
         </tr>
          <tr>
         <td>
        <label for="production">production: 
        <input type="text"  value="<?php echo $affaire['production'] ?>"
        name="production" readonly required id="prod" 
        placeholder="Taper un production" 
        class="form-control"/></label>
        </td>
         <td>
        <label for="solde">solde en DH:  
        <input type="text" value="<?php echo $affaire['solde'] ?>"
        name="solde" readonly  id="solde"  
        class="form-control"/></label>
        </td>
        
         <td>
         etat:  &nbsp &nbsp <?php if($affaire['etat']==1) 
          $et='active';
          else if($affaire['etat']==0)
            $et='complet';
          else
            $et='annuler';
          ?>
         <select name="etat" class="form-control col-lg-12 date1" id="etat"  disabled>
             <option value="1" <?php if($affaire['etat']==1) echo'selected'; ?>>active</option>
             <option value="0"<?php if($affaire['etat']==0) echo'selected'; ?>>complet</option>
             <option value="-1" <?php  if($affaire['etat']==-1) echo'selected';?>>annuler</option>
         </select>
         </td>
          </tr>
          </table>
         
        <button type="reset" name="reset" class="btn btn-danger">
          <span class="fa fa-remove"></span> 
          Reset 
        </button>
         <button type="submit" name="save" class="btn btn-success" >
          <span class="fa fa-save"></span> 
          Save
        </button>&nbsp &nbsp
        <a href="javaScript:history.back()" id="rt">retour </a>
        </div>
      </div>

    </form>
  </div>
                    
    
     <div class="col col-md-6">
       <div class="card-header bg-success text-white"> <center><a href="fractions.php?fraction=<?php echo $affaire["police"] ?>" style="color:orange; font-size: 23px;"> Leur fractions: </a></center></div> 
     <br>
     
  <div class="card-body text-info bg-light">
     <table class="table table-striped  table-responsive table-bordered tb1">
       <?php $i=1; while($fraction = mysqli_fetch_array($resultatFraction)) {
                      $req="SELECT * from reglement,fractions where (fractions.id=reglement.fraction) and fractions.affaire='$id'";
                        $res=mysqli_query($conn,$req);
                       $bgClr=mysqli_num_rows($res)>0?'bg-danger':'';
                       $clr=mysqli_num_rows($res)>0?'text-white':''; ?>
                  <thead>
                    <tr>
                   <th class="bg-secondary" colspan="8"> <center>fraction <?php echo $i; ?></center></th></tr>
                   <tr class="bg-primary">
                    <th>Id</th> 
                    <th>affaire</th>
                    <th >montant</th>  
                    <th colspan="2">date_effet</th> 
                    <th colspan="2">date_reg</th>
                    <th >solde</th>
                   </tr>
                  </thead>
                  <tbody>
                   
                       
                    <!--code Html pour remplier le tab-->
                          <tr>
                            <td> <?php echo $fraction['id'] ?> </td>
                            <td> <?php echo $fraction['affaire'] ?> </td>
                            <td > <?php echo $fraction['montant'] ?> </td>
                            <td colspan="2"> <?php echo $fraction['date_effet'] ?> </td>
                            <td colspan="2"> <?php echo $fraction['date_reg'] ?> </td>
                            <td> <?php echo $fraction['solde'] ?> </td>
                           
                          </tr>
                          <tr>
                        <th class="bg-secondary" colspan="
                        8"> <center>reglement <?php echo $i; $i++; ?></center></th></tr>
                         <?php 
                          $idF=$fraction['id'];
                          $req2="SELECT reglement.id as'id' ,reglement.fraction as'fraction',reglement.montant as'montant',reglement.datea as'datea',reglement.mode as'mode',reglement.ref as'ref',reglement.validation as'validation' from reglement,fractions where (reglement.fraction=fractions.id) and reglement.fraction=$idF order by reglement.id desc";
                          $res2=mysqli_query($conn,$req2);
                          if(mysqli_num_rows($res2)>0){
                          echo' 
                         <tr class="bg-warning">
                          <th>Id</th> 
                          <th>fraction</th>
                          <th>montant</th>
                          <th>date_regler</th>  
                          <th>mode</th> 
                          <th>ref</th>
                          <th>validation</th>
                          <th>actions</th>            
                         </tr>
                          </tr>';
                         }
                           while($reg=mysqli_fetch_assoc($res2)){ 
                            $mode=$reg["mode"]==1?"espece":"cheque";
                            $valider=$reg["validation"]==1?"valider":"non valider";
                          echo '
                          <tr> <td>'. $reg["id"].' </td> <td> '.$reg["fraction"].' </td><td>'.$reg["montant"].'</td><td>'. $reg["datea"] .'</td> <td>'. $mode.' </td> <td> '.$reg["ref"].' </td><td>'.$valider .'</td>' ;?>
                          <td> 
                            &nbsp &nbsp
                         <a onclick="return confirm('vous etes sur de supp?')"
                        href="supprimerReglement.php?id=<?php echo $reg['id'] ?>&idA=<?php echo $id ?>"><span class="fa fa-trash"></span></a>

                           </td>
                        
                         <?php echo '</tr>'; } ?>
                          
                         <?php  if($fraction['solde']!=0) {?>
                        <tr>
                   <td colspan="8">
                   <form method="post" action="insertReglement.php" class="form">
       <div class="form-group ">
        <input type="hidden" class="form-control" name="affaire" value="<?php echo $id ?>">
         <label for="fraction">Fraction:<?php echo $fraction['id'] ?></label>
         <input type="hidden" class="form-control" name="fraction" id="fraction" value="<?php echo $fraction['id']?>">
         <input type="hidden" class="form-control" name="soldeF" id="soldeF" value="<?php echo $fraction['solde']?>">
         <input type="hidden" class="form-control" name="soldeA" id="soldeA" value="<?php echo $affaire['solde']?>">
           <br>
         <label for="mantant">montant:
        <input type="number" step="any" max="<?php  echo $fraction['solde'] ?>" min="0"value="<?php  echo $fraction['solde'] ?>" 
        name="montant" id="mn"
        class="form-control" required/></label>

         <label for="date">date_reg:
         <input type="date"id="datea"
         name="datea" value="<?php echo date('Y-m-d')?>" 
         class="form-control" required/></label>

         <label for="date">mode:
         <select name="mode" id="mode" class="form-control">
           <option value="1" selected>espece</option>
           <option value="0">cheque</option>
         </select></label>

         <label for="ref">ref:
         <input type="text" id="ref" readonly
         name="ref" value="<?php 
         include'connexiondb.php';
         
          do{
                 $str='ABCDEFGHIJKLMNOPQRSTUVYXYZ';
                 $str1='0123456789';
                 $rand=substr(str_shuffle($str),-4);
                 $rand.=substr(str_shuffle($str1),-4);
                 $query="SELECT * from reglement where ref='$rand'";
                 $res=mysqli_query($conn,$query);
         }
         while(mysqli_num_rows($res)>0);
          echo $rand;
         
        ?>" 
         class="form-control"required/></label>

         <label for="validation">validation:
         <select name="validation" id="validation" class="form-control">
           <option value="1" selected>valider</option>
           <option value="0">non valider</option>
         </select></label>
          <br>
        <button type="submit" name="save" class="btn btn-success" value="save">
          <span class="fa fa-money"></span> 
          Payer
        </button>
       
      </div>
    </form>

  </td>
</tr>
<?php } ?>
</tbody>
<?php  } ?>
</table>

</div>




</div>

  </div>
</div>
        </div>
</div>
       </body>

<footer>
  
<?php
            include("footer.php");
             ?>
</footer>

 </html> 