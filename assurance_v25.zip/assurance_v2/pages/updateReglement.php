<?php
require_once("identifier.php");

require_once('connexiondb.php');
 $idA=isset($_POST['affaire'])?$_POST['affaire']:0;
 $idR=isset($_POST['id'])?$_POST['id']:0;
  $req1="SELECT reglement.id as'idR',reglement.montant as'montantR',fractions.id as'idF',fractions.solde as'solde',fractions.montant as'montantF', affaires.id as'idA',affaires.solde as'soldeA',affaires.production as'production' from reglement,fractions,affaires where (reglement.fraction=fractions.id and affaires.id=fractions.affaire) and reglement.id=$idR";
 $res1=mysqli_query($conn,$req1);
 $reg=mysqli_fetch_assoc($res1);
 $validation=isset($_POST['validation'])?$_POST['validation']:0;
 $fraction=isset($_POST['fraction'])?$_POST['fraction']:0;
 $montant=isset($_POST['montant'])?$_POST['montant']:0;
 $oSolde=isset($_POST['oSolde'])?$_POST['oSolde']:0;
 $datea=isset($_POST['datea'])?$_POST['datea']:date('Y-m-d');
 $mode=isset($_POST['mode'])?$_POST['mode']:0;
 $ref=isset($_POST['ref'])?$_POST['ref']:"";
 
   
 $requete="UPDATE reglement SET  fraction='$fraction',montant='$montant',datea='$datea',mode='$mode',ref='$ref',validation='$validation' where id=$idR";
 $resultat=mysqli_query($conn,$requete);
 $dff=$oSolde-$montant;
 $nSoldeF=$reg['solde']+$dff;
 $nSoldeA=$reg['soldeA']+$dff;

 $idF=$reg["idF"];
 $req="UPDATE fractions set solde='$nSoldeF' where id='$idF'";
 $res=mysqli_query($conn,$req);
 $req2="UPDATE affaires set solde='$nSoldeA' where id='$idA'";
 $res2=mysqli_query($conn,$req2);
  
 echo '<script> window.location.href="reglerAffaire.php?id='.$idA.'"; </script>';

?>