<?php
 require_once("identifier.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>ajouter compagnie</title>
<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
	?>
<div class="container col-lg-6 col-lg-offset-4">
	<div class="util" >
	<div class="card">
		<div class="card-header bg-info text-white">
		ajouter une nouvelle compagnie</div>
	    <div class="card-body text-info bg-light">
	    	<form method="post" action="newCompagnie.php" class="form">

 			<div class="form-group " >
   				<label>nom:
 					<input type="text" name="nom" class="form-control" minlength="3" maxlength="30" pattern="^[a-zA-Z\s_]{3,}$"  autocomplete="off" required></label>
 					<label >adresse:
 			   <input type="text" name="adresse"class="form-control" minlength="3" maxlength="500" pattern="([\w\s-]){3,}" autocomplete="off"required></input>
 			   </label>
 			   <label>cp:
 					<input type="text" name="cp"class="form-control""minlength="3" maxlength="20"pattern="^([\d]){3,}" autocomplete="off"></label> 
 					<label>ville:
 					<input type="text" name="ville" minlength="3" maxlength="50"pattern="^([a-zA-Z_ \s -]){3,}$" class="form-control" autocomplete="off"required></label>
 					<label >tel:
 			   <input type="text" name="tel"class="form-control"minlength="9" maxlength="15" pattern="^(0|\+([0-9]){2,3})([0-9]){8,9}$" autocomplete="off"required></input>
 			   </label>
 			   <label>fax:
 					<input type="text" name="fax"class="form-control"minlength="9" maxlength="15"pattern="^(0|\+([0-9]){2,3})([0-9]){8,9}$" autocomplete="off"></label>
 					<label>mail:
 					<input type="text" name="mail"class="form-control"minlength="11" maxlength="50" pattern="^([a-zA-Z]){1}([\w.])*(@gmail\.com){1}$" autocomplete="off"required></label><br><br>
                
                <div class="err">
                  <?php 
                  if(isset($_POST['sub3']))
                     require("insertCompagnie.php");
                  ?>
                </div>	
 					<button type="reset" name="reset"class="btn btn-danger" >
 						<i class="fa fa-remove"></i> &nbsp reset
 					</button> 
          <button type="submit" name="sub3"class="btn btn-success" >
            <i class="fa fa-save"></i> &nbsp Enregistrer
          </button><br><br>
 				<a href="javaScript:history.back()" id="rt">retour </a>
 			</div>



	    </div>
</div>

</div></div>
 <?php
 include 'footer.php';
 ?>
</body>
</html>