<?php
 require_once("identifier.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Ajoute utilisateur</title>
	<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
	?>
<div class="container col-lg-4 col-lg-offset-3 col-md-6 col-md-offset-3">
	<div class="util" >
	<div class="card">
		<div class="card-header bg-info text-white">
		ajouter un nouveau utilisateur</div>
	    <div class="card-body text-info bg-light">
	    	<form method="post" action="newUser.php" class="form">

 			<div class="form-group " >
        
 				<label>login:
 					<input type="text" name="login" class="form-control" minlength="3" maxlength="30" pattern="^[a-zA-Z\s_]{3,}$" autocomplete="off"required></label><br>
          <div class="input-group">
 					<label >password:
 			   <input type="password" id="pass1"name="pwd" minlength="4" maxlength="20"class="form-control"required>
 			   </label><br><span id="iconn2" class="ico"> <i  class="fa fa-eye-slash fa-3x"></i></span>
         </div>
 			   <label>email:
 					<input type="email" name="email"class="form-control" minlength="11" maxlength="50" pattern="^([a-zA-Z]){1}([\w.])*(@gmail\.com){1}$" autocomplete="off"required></label>
 					<br><label>type: &nbsp &nbsp
          <select name="type" class="form-control" required>
            <option value="1">Admin</option>
            <option value="0" selected>User</option>
          </select></label>

          <br><label>etat: &nbsp &nbsp
          <select name="etat" class="form-control" required>
            <option value="1">active</option>
            <option value="0" selected>desactive</option>
          </select></label>
                <div class="err">
                	<?php 
                	if(isset($_POST['sub2']))
                     require("insertUser.php");
                	?>
                </div>	
                <button type="reset" name="reset2"class="btn btn-danger" >
 						<i class="fa fa-remove"></i> &nbsp reset
 					</button>
 					<button type="submit" name="sub2"class="btn btn-success" >
 						<i class="fa fa-save"></i> &nbsp Enregistrer
 					</button><a href="javaScript:history.back()" id="rt">retour </a>
 					
 			</div>



	    </div>
</div>

</div></div>
<?php
include 'footer.php';
?>
</body>
</html>