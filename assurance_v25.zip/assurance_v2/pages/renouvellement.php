
<?php
require_once("identifier.php");

require_once("connexiondb.php");


$size=isset($_GET['size'] ) ?$_GET['size']: 20;    
$page=isset($_GET['page'] ) ?$_GET['page']: 1;
$dureeR=isset($_GET['dureeR'])?$_GET['dureeR']:30;
$offset= ($page-1)*$size ; 
$dateA=date('Y-m-d',strtotime('-1 day'));
if ($dureeR==1)
	$dateR=strtotime($dateA.' -'.$dureeR.' day');
else
$dateR=strtotime($dateA.' -'.$dureeR.' days');

$dateA=strtotime(date('Y-m-d',strtotime('-1 day')));
$requet =  "SELECT affaires.id,affaires.datea,affaires.timea,compagnies.mail as'mail1',affaires.police,affaires.numAttest,affaires.type,affaires.ferme,clients.cin,risque.matricule , affaires.production,affaires.nbrFractions,affaires.duree,affaires.datei,affaires.datef,affaires.solde,affaires.obs,affaires.etat,affaires.op FROM affaires , clients, risque,compagnies where (clients.id=affaires.client and  risque.id=affaires.risque and compagnies.id=affaires.compagnie) and (UNIX_TIMESTAMP(affaires.datef) < $dateA and UNIX_TIMESTAMP(affaires.datef)>= $dateR)
order by affaires.datef desc limit $size 
offset $offset ";
$requetCount="SELECT count(*) countC FROM affaires , clients, risque where (clients.id=affaires.client and risque.id=affaires.risque ) and (UNIX_TIMESTAMP(affaires.datef) < $dateA and UNIX_TIMESTAMP(affaires.datef) >=  $dateR) ";

$resultatAffaire = mysqli_query( $conn,$requet) ;  
$resultatCount =mysqli_query( $conn,$requetCount) ;
$tabCount=  mysqli_fetch_array($resultatCount) ;
$nbrAffaire= $tabCount['countC'];
$rest=$nbrAffaire%$size;  
if($rest===0)
  $nbrPage=$nbrAffaire / $size;
else
  $nbrPage= floor($nbrAffaire/ $size) +1; 
?>
<!DOCTYPE HTML>
<html>
<head>
  <meta charset="utf-8">
  <title>Revouvellement</title>
  <?php require("styleLinks.php");?>
</head>
<body>
 <?php
 include("header.php");
 ?>
 <div class="container col-lg-12 col-md-12 col-sm-12">

  <div class="card "> 

   <div class="card-header bg-success">

    <center>Renouvelement</center> 
   </div>
   <div class="card-body">
    <form method="get" action="renouvellement.php" class="form-inline">
     <div class="form-group">

      <lable > &nbsp &nbsp &nbsp &nbsp &nbsp  duree:&nbsp&nbsp&nbsp </lable>
	    	 	<select name="dureeR" class="form-control" id="dureeR" >
	    	 		<option value="30" >30 jours</option>
	    	 		<option value="15" >15 jours</option>
	    	 		<option value="7"  >7 jours</option>
	    	 		<option value="2"  >2 jours</option>
	    	 		<option value="1"  >1 jour</option>
	    	 	</select>
    </div>
    
 </form>
</div>
</div>

<div class="card  "> 

  <div class="card-header bg-primary">Liste des Affaires [<?php echo $nbrAffaire ?>  Affaires] </div>

  <div  class="card-body text-info bg-light">
  <div id="renou01">
    <table  class="table table-striped table-bordered  table-responsive tb">
      <thead >
       <tr >
        <th>Id[<?php echo $nbrAffaire ?>] </th> <th>DateAssurer</th>  <th>Time</th>  <th> Cmpg</th>  <th>police</th> <th>numAttest</th>    
        <th>type</th>  <th>ferme</th> <th>clt</th> <th>risque_mat</th> <th>prod</th><th><a href="fractions.php" title="les fractions">nbrFractions</a></th>
        <th>duree</th>  <th>date_debut</th> <th>date_fin_aff</th> <th>solde</th><th>etat</th><th>op</th><th>observation</th>
      </tr>
    </thead>
    <tbody>
      <?php while($affaire = mysqli_fetch_array($resultatAffaire)) { 
        $affr=$affaire['id'];
               $req="SELECT * from fractions where affaire=$affr";
               $res=mysqli_query($conn,$req);
               $bgClr=mysqli_num_rows($res)>0?'bg-white':'';
                $clr=mysqli_num_rows($res)>0?'text-dark':'';
                $bgClr=$affaire['solde']!=$affaire['production']?'bg-warning':$bgClr;
                if($bgClr){ 
                     ?>
        
        <tr class="<?php echo $clr.' '.$bgClr; ?>">
          <td> <?php echo $affaire['id'] ?> </td>
          <td> <?php echo $affaire['datea'] ?> </td>
          <td> <?php echo $affaire['timea'] ?> </td>
          <td><a href="compagnie.php?nameC=<?php echo $affaire['mail1'] ?>"> <?php echo $affaire['mail1'] ?> </td>
          <td><a href="affaires.php?client=<?php echo $affaire['police'] ?>">  <?php echo $affaire['police'] ?> </a></td>
          <td> <?php echo $affaire['numAttest'] ?> </td>
          <td> <?php 
          $type=$affaire['type']==1? 'auto':'moto';
          echo  $type ?> </td>
          <td> <?php 
          $ferme=$affaire['ferme']==1? 'ouvert':'ferme';
          echo  $ferme ?> </td>
          <td> <a href="clients.php?cin=<?php echo $affaire['cin'] ?>" title="client"><?php echo $affaire['cin'] ?></a> </td>
          <td><a href="vehicules.php?matricule=<?php echo $affaire['matricule'] ?>" > <?php echo $affaire['matricule'] ?> </a></td>
          <td> <?php echo $affaire['production'] ?> </td>
         <td><a href="fractions.php?fraction=<?php echo $affaire['police'] ?>"> <?php echo $affaire['nbrFractions'] ?> fractions</a> </td>
          <td> <?php echo $affaire['duree'] ?> mois</td>
          <td> <?php echo $affaire['datei'] ?> </td>
          <td> <?php echo $affaire['datef'] ?> </td>
          <td> <?php echo $affaire['solde'] ?> DH</td>
          
          <td> <?php 
          $et=$affaire['etat'];
          if($et==1)
            $etat="active";
          else if($et==0)
            $etat="complet";
          else $etat="annuler";

          echo $etat ?> </td>
         <td> <a href="utilisateur.php?loginU=<?php echo $affaire['op'] ?>" ><?php echo $affaire['op'] ?> </a></td>
         <td><textarea name="obs" id="obs1" readonly class="<?php echo $bgClr ?>"> <?php echo $affaire['obs'] ?> </textarea> <br>
        &nbsp <a href="editObsA.php?id=<?php echo $affaire['id'] ?>" > <i class="fa fa-edit"></i> </a>&nbsp &nbsp &nbsp &nbsp
         <a href="supprimerObsA.php?id=<?php echo $affaire['id'] ?>" > <i class="fa fa-trash"></i> </a>
          </td>
        </tr>
      <?php  } }?>

    </tbody>
  </table>
</div>
  <div >
   <ul class="pagination ">
    <?php
    for($i=1;$i<=$nbrPage;$i++){ ?>

     <li class="<?php if($i == $page) echo'active' ?> page-item"> <a class="page-link"href="reglement.php ?page=<?php echo $i;?>">  <?php echo $i;?>  </a> </li> 

   <?php   } ?>

 </ul>
</div>
<a href="javaScript:history.back()" id="rt">retour </a>
</div>
</div>
</div>

</body>



</html><?php
include("footer.php");
?>