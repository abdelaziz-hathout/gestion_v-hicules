
<?php
require_once("identifier.php");

require_once('connexiondb.php');
$id=isset($_GET['id'])?$_GET['id']:0;
$requete="select * from mandataires where id=$id";
$resultat=mysqli_query($conn,$requete);
$mandataire=mysqli_fetch_array($resultat);

$nom=$mandataire['nom'];
$cin=$mandataire['cin'];
$adresse=$mandataire['adresse'];
$ville=$mandataire['ville'];
$cp=$mandataire['cp'];
$tel=$mandataire['tel'];
$ice=$mandataire['ice'];
$mail=$mandataire['mail'];
$activite=$mandataire['activite'];
$obs=$mandataire['obs'];



?>

<!DOCTYPE HTML>
 <html>
    <head>

      <meta charset="utf-8">
      <title>Edition d'un mandataire</title>
     <?php require("styleLinks.php");?>
    </head>
       <body>
  
           <?php   include("header.php"); ?>

        
           <div class="container">
             
            
             
             <div class="card margetop60"> 
              
              <div  class="card-header bg-primary"> Edition du mandataire</div>
              
              <div class="card-body text-info bg-light">

                <form method="post" action="updateMandataires.php" class="form">
                  <div class="form-group ">
                   <label for="id">Id: <?php echo $id?>
                   <input type="hidden"
                   name="id"
                   placeholder="Taper un id" 
                   class="form-control"
                   value="<?php echo $id?> "/></label><br>
                                
         <label for="nom">Nom:
        <input type="text"minlength="3" maxlength="30" value="<?php echo $nom ?>" pattern="^[a-zA-Z\s_]{3,}$" 
         name="nom" required value="<?php echo $nom ?>" 
         class="form-control"/></label>

         <label for="cin">Cin:
         <input type="text"
         name="cin" required minlength="5" maxlength="10" value="<?php echo $cin ?>" pattern="^([a-zA-Z0-9]){5,10}" 
         class="form-control"/></label>

         <label for="adresse">Adresse:
         <input type="text"minlength="3" maxlength="500" value="<?php echo $adresse ?>" pattern="([\w\s-]){3,}" 
         name="adresse"    
         class="form-control"/></label>

         <label for="ville">Ville:
         <input type="text"minlength="3" maxlength="50"value="<?php echo $ville ?>" pattern="^([a-zA-Z_ \s -]){3,}$"
         name="ville"     
         class="form-control"/></label>
         <label for="cp">Cp:
         <input type="text"minlength="3" maxlength="20"value="<?php echo $cp ?>" pattern="^([\d]){3,}"
         name="cp"      
         class="form-control"/></label>
         <label for="tel">Tel:
         <input type="text"minlength="9" maxlength="15" value="<?php echo $tel ?>" pattern="^(0|\+([0-9]){2,3})([0-9]){8,9}$" 
         name="tel"     
         class="form-control"/></label>
         <label for="ice">Ice:
         <input type="text"minlength="3" maxlength="50"pattern="^([a-zA-Z0-9]){3,}" 
         name="ice" value="<?php echo $ice ?>"  
         class="form-control"/></label>
         <label for="mail">Email:
         <input type="text"minlength="11" maxlength="50" value="<?php echo $mail ?>" pattern="^([a-zA-Z]){1}([\w.])*(@gmail\.com){1}$" 
         name="mail"      
         class="form-control"/></label>
         <label for="activite">Activite:
         <input type="text"minlength="3" value="<?php echo $activite ?>" pattern="^([a-zA-Z\s_-]){3,}"
         name="activite"     
         class="form-control"/></label>
         <label for="ops">Obs:
         <input type="text"minlength="3"value="<?php echo $obs ?>" pattern="^([a-zA-Z]){3,}([\w\s:_])*"
         name="obs"       
         placeholder="observation" 
         class="form-control"/></label>
  
                </div>


                         <div class="form-group col-md-8">
                  <button  type="reset" class="btn btn-danger" >
                    <span class="fa fa-remove"></span> 
                   reset
                      </button>
                      <button  type="submit" class="btn btn-success" value="save">
                    <span class="fa fa-save"></span> 
                    Update
                      </button>&nbsp &nbsp
                      <a href="javaScript:history.back()" id="rt">retour </a>
                      </div>
                </form>
              </div>
             </div>

        </div>
        

       </body>

<footer>
  
<?php
            include("footer.php");
             ?>
</footer>

 </html> 