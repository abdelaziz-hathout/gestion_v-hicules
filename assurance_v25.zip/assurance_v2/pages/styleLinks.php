<link rel="stylesheet" type="text/css" href="../styles/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../styles/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="../styles/css/css3.css">
  <link rel="stylesheet" type="text/css" href="../js/jquery-ui/jquery-ui.css">
  <link rel="stylesheet" type="text/css" href="../js/jquery-ui/jquery-ui.theme.css">
  <link rel="stylesheet" type="text/css" href="../js/jquery-ui/jquery-ui.structure.css">
  <link rel='shortcut icon' href='../images/AssuranceAR1.png' />
  <script src="../styles/bootstrap/js/bootstrap.bundle.min.js" ></script>
  <script src="../js/jquery.js"></script>
  <script src="../js/jquery-ui/jquery-ui.js"></script>
  <script src="../js/js3.js"></script>