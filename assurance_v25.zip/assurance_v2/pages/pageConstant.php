
<!DOCTYPE HTML>
 <html>
    <head>

      <meta charset="utf-8">
      <title>Page Constant</title>
      <link rel="stylesheet" href="../css/bootstrap.min.css">
      <link rel="stylesheet" href="../css/style.css">
    
    </head>
       <body>
  
           <?php  
           require_once("identifier.php");

           include("menu.php"); ?>

         <!-- intégrer notre panneau aux milieu de la page !-->
         <div class="container">
        <!-- panneau de recherche-->  
            <div class="panel panel-success margetop"> 
       <!-- intégrer la partie de recherche !-->
            <div class="panel-heading">Chercher des clints avec CIN</div>
        <!--intégrer le contenu de recherche !-->
              <div class="panel-body">Le contenu</div>
             </div>

     <!--------------------------------------------------------- -->

        <!-- panneau du contenu de l'interface-->
             <div class="panel panel-primary "> 
      
            <div class="panel-heading">Liste des clients</div>
    
              <div class="panel-body">Le Tableau des clients</div>
             </div>

        </div>
        

       </body>

<footer>
  
<?php
            include("footer.php");
             ?>
</footer>

 </html>