

<?php
require 'identifier.php';
require_once("connexiondb.php");

$loginU=isset($_POST['loginU'])?$_POST['loginU']:"";
$loginU=strtoupper($loginU);
$type=isset($_POST['type'])?$_POST['type']:"all";
	$req="SELECT * from users order by id desc";
      
if($type=="all"){
 $req="SELECT * from users where UPPER(login) like '$loginU%' or UPPER(email) like '$loginU%' order by id desc";
 $reqCount="SELECT count(*) countU from users where (UPPER(login) like '$loginU%' or UPPER(email) like '$loginU%') ";
} else {
	$req="SELECT * from users where (UPPER(login) like '$loginU%'  or UPPER(email) like '$loginU%') and type='$type' order by id desc";
	$reqCount="SELECT count(*) countU from users where (UPPER(login) like '$loginU%' or UPPER(email) like '$loginU%') and type='$type'";
}
$res=mysqli_query($conn,$req);
$reqCount=mysqli_query($conn,$reqCount);
$tabCount=mysqli_fetch_assoc($reqCount);
$nbrUsers=$tabCount['countU'];
        if(mysqli_num_rows( $res)>0){
echo '<table class="table table-striped tabble-border table-responsive tb"><tr> <th>Id ['.$nbrUsers.']</th>
	  <th>login</th>
	 <th>email</th>
	 <th>type</th>';
	 if(isset($_SESSION["type"]) && $_SESSION["type"]==1){
	 echo '<th>Actions</th>';
	   }
	  echo '</tr>';
while ($users=mysqli_fetch_assoc($res)) {
	if($users['type']==1)
		$user="admin";
	else $user="user";
	if($users['etat']==1){
		$class="bg-success";
		$ico='<i class="fa fa-check-circle active"></i>';
	}
	else {
		$class="bg-danger";
		$ico='<i class="fa fa-ban active"></i>';
	}    
	
	echo '<tr class=" '.$class.' text-white"> <td>'. $users["id"].' </td> <td> '.$users["login"].' </td><td>'. $users["email"] .'</td> <td>'.$user.'</td>';

	if(isset($_SESSION['type']) && $_SESSION['type']==1){
		echo  '<td id="act">
		<a  href="editUser.php?id='.$users["id"].' " ><span class="fa fa-edit"></span></a> 
		&nbsp
		<a onclick="return confirm(\'vous etes sur de supp?\')"
		href="deleteUser.php?id='.$users["id"].' " ><span class="fa fa-trash"></span></a>
		&nbsp  <a  href="activerUser.php?id='.$users["id"].'&etat='.$users["etat"].' " >
		'.$ico.'
	  	</a></td>';
	  }

	   

	    				
        }
        echo "</tr></table>";
    }
    else echo '&nbsp &nbsp &nbsp aucun user trouv&eacute;.';

   
        ?>