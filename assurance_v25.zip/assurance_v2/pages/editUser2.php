<?php
 require_once("identifier.php");
 
 require_once ("connexiondb.php");
 $id=isset($_GET['id'])?$_GET['id']:0;
 $req="select * from users where id='$id'";
 $res=mysqli_query($conn,$req);
 $user1=mysqli_fetch_assoc($res);
 $login=$user1['login'];
 $pwd=$user1['pwd'];
 $email=$user1['email'];
 $type=$user1['type'];
 $etat=$user1['etat'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>utilisateur</title>
<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
	?>
<div class="container col-lg-5 col-lg-offset-3 col-md-6 col-md-offset-3">
	<div class="util" >
	<div class="card">
		<div class="card-header bg-info text-white">
		modifier un utilisateur</div>
	    <div class="card-body text-info bg1">
	    	<form method="post" action="editUser2.php" class="form-check" >

 			<div class="form-group">
 				<label>id: <?php echo $_SESSION['id']?>
 					<input type="hidden" name="id" class="form-control" autocomplete="off" value="<?php echo $_SESSION['id']?>"></label><br>
 					<label>login:
 					<input type="text" name="login" class="form-control"minlength="3" maxlength="30" pattern="^[a-zA-Z\s_]{3,}$"  autocomplete="off" value="<?php echo  $_SESSION['user']?>" required></label><br>
          <div class="input-group">
 					<label>password:
          <input type="password"  id="pass1" name="pwd"minlength="4" maxlength="20" class="form-control" autocomplete="off" value="<?php echo $_SESSION['pwd']?>" required></label><br><span id="iconn2" class="ico"> <i  class="fa fa-eye-slash fa-3x eye"></i></span>
           </div>
 			   <label>email:
 					<input type="email" name="email"class="form-control"minlength="11" maxlength="50" pattern="^([a-zA-Z]){1}([\w.])*(@gmail\.com){1}$"  autocomplete="off" value="<?php echo $_SESSION['email']?>" required></label><br>

          <label>type: <?php if($_SESSION['type']==1) echo 'admin.'; else echo 'user.'?>
          <input type="hidden" name="type"class="form-control" autocomplete="off" value="<?php echo $_SESSION['type']?>" required></label><br>

          <label>etat: <?php if($_SESSION['etat']==1) echo 'activer.'; else echo 'd&eacute;sactiver.'?>
          <input type="hidden" name="etat"class="form-control" autocomplete="off" value="<?php echo $_SESSION['etat']?>" required></label><br>

           
                <div class="err">
                	<?php 
                	if(isset($_POST['sub4']))
                     require("updateUser.php");
                	?>
                </div>	
 					<button type="submit" name="sub4"class="btn btn-success" >
 						<i class="fa fa-save"></i> &nbsp modifier
 					</button>&nbsp &nbsp
         
 					<a href="javaScript:history.back()" id="rt">retour </a>
 			</div>



	    </div>
</div>

</div></div>
<?php include'footer.php'; 


?>
</body>
</html>




