
<?php

require_once ("connexiondb.php");

$email=isset($_POST['email'])?$_POST['email']:"";

$req="select * from users where email='$email'";
$res=mysqli_query($conn,$req);
$user=mysqli_fetch_assoc($res);
$id=$user['id'];
do{
     $newPwd=rand(1000,9999);
     $query="SELECT * from users where pwd='$newPwd'";
     $res=mysqli_query($conn,$query);
 }
 while(mysqli_num_rows($res)>0);

if($user){
	$sql="UPDATE users SET pwd='$newPwd' where id='$id' ";
	$res1=mysqli_query($conn,$sql);
	if($res1){
		$to = $email;
		$from = "gsomeone375@gmail.com";
		$subject = "Réinitialisation du mot de passe";
		$txt = "Votre nouveau mot de passe est: ".$newPwd;
		$headers = "From: ".$from."\r\n" .
		"CC:". $email;

		mail($to,$subject,$txt,$headers);
		echo "votre mot de passe est r&eacute;initialis&eacute;";
		/*echo '<script> setTimeout(function(){
         window.location.href="login2.php";
		},3000) ; </script>';*/
	}
	else echo"erreur";
}
else {
	echo "email incorrect!";
}

?>