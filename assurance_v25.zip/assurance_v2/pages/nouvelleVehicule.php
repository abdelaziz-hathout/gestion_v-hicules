<?php
require_once("identifier.php");
?>
<!DOCTYPE HTML>
<html>
<head>

  <meta charset="utf-8">
 <?php require("styleLinks.php");?>


</head>
<body>

 <?php 
 require_once("identifier.php");

 include("header.php"); ?>


 <div class="container col-lg-4 col-lg-offset-3 col-md-8 col-md-offset-2">



   <div class="card  margetop60"> 

    <div class="card-header bg-primary">Saisir les données du Risque</div>
    
    <div class="card-body text-info bg-light">


      <form method="post" action="insertVehicules.php" class="form" id="veh">
       <div class="form-group ">
         <label for="marque">Marque:</label>
         <input type="text " minlength="3" pattern="^([a-zA-Z_-]){3,}" 
         name="marque" required id="marque" 
         placeholder="Taper un Marque"  autofocus 
         class="form-control"/>
         <div id="errM"></div>
          <br>
         <label for="matricule">Matricule:</label>
         <input type="text " minlength="6" pattern="^([\w-]){6,}" 
         name="matricule"  required  autocomplete="off " 
         placeholder="Taper un Matricule" 
         class="form-control"/><br>

         <button type="reset" name="reset" class="btn btn-danger">
          <span class="fa fa-remove"></span> 
          Save
        </button>
        <button type="submit" name="save" class="btn btn-success" value="save">
          <span class="fa fa-save"></span> 
          Save
        </button>
        &nbsp &nbsp
        <a href="javaScript:history.back()" id="rt">retour </a>
      </div>
    </form>
  </div>
</div>

</div>


</body>

<footer>

  <?php
  include("footer.php");
  ?>
</footer>

</html> 