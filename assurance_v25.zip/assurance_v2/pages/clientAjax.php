<?php  

        require_once("connexiondb.php");
        $input=isset($_POST['cin'] ) ?$_POST['cin']:"";
        $input=strtoupper($input);
       $requet = "SELECT clients.id,clients.nom,clients.cin,clients.contact,clients.adresse,clients.ville,clients.cp,clients.tel,clients.fax,clients.ice,clients.mail,clients.activite,clients.obs,clients.pays,mandataires.cin as'cin1' FROM clients left outer join mandataires on (clients.mandataire=mandataires.id) where  ( UPPER(clients.cin) like'$input%' or UPPER(clients.tel) like'$input%' or UPPER(clients.mail) like'$input%') order by clients.id desc";
       $requetCount="SELECT count(*) countC from clients where UPPER(cin) like'$input%'or UPPER(tel) like'$input%' or UPPER(mail) like'$input%' ";
       $resultatclients = mysqli_query($conn,$requet) ;
       $resultatCount =mysqli_query( $conn,$requetCount) ;
        $tabCount=  mysqli_fetch_array($resultatCount) ;
        $nbrClient= $tabCount['countC'];
        if(mysqli_num_rows( $resultatclients)>0){
       echo '<table class="table table-striped table-bordered table-responsive tb"><tr><th>Id ['.$nbrClient.']</th> <th>Nom</th>  <th>CIN</th>  <th>Contact</th>  <th>Adress</th> <th>Ville</th>    
                    <th>Cp</th>  <th>Tel</th> <th>Fax</th> <th>Ice</th> <th>Email</th><th>Activite</th>
                    <th>Obs</th>  <th>Pays</th> <th><a href="mandataires.php" title="listes des mandataires">Mandataires</a></th> <th>Action</th>      
                   </tr>';
        while ($clients=mysqli_fetch_assoc($resultatclients)) {
          $idClt=$clients['id'];
                     $req="SELECT * from affaires where client=$idClt";
                     $res=mysqli_query($conn,$req);
                     $bgClr=mysqli_num_rows($res)>0?'bg-danger':'';
                     $clr=mysqli_num_rows($res)>0?'text-white':''; 
          echo '<tr class="'.$clr.' '.$bgClr.'"> <td>'. $clients["id"].' </td> <td> '.$clients["nom"].' </td><td>'. $clients["cin"] .'</td> <td>'. $clients["contact"].' </td> <td> '.$clients["adresse"].' </td><td>'. $clients["ville"] .'</td> <td>'. $clients["cp"].' </td> <td> '.$clients["tel"].' </td><td>'. $clients["fax"] .'</td> <td>'. $clients["ice"].' </td> <td> '.$clients["mail"].' </td> <td> '.$clients["activite"].' </td><td>'. $clients["obs"] .'</td> <td>'. $clients["pays"].' </td> <td><a  href="mandataires.php?cin='.$clients["cin1"].'" > '.$clients["cin1"].'</a> </td><td>
                            <a  href="editerClient.php?id='.$clients["id"].' " ><span class="fa fa-edit"></span></a> 
                              &nbsp';
                           if($bgClr!="bg-danger"){
                          echo'<a onclick="return confirm(\'vous etes sur de supp?\')"
                        href="supprimerClient.php?id='.$clients["id"].' " ><span class="fa fa-trash"></span></a>';
                         }
                          echo' </td> ';
       
      }
        echo "</tr></table>";
      
      }
      else echo '&nbsp &nbsp &nbsp aucun client trouv&eacute;.';

?>