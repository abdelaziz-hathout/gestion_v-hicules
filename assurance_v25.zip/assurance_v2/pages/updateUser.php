<?php
 require_once("identifier.php");
require_once('connexiondb.php');
 $id=isset($_POST['id'])?$_POST['id']:0;
 $login=isset($_POST['login'])?$_POST['login']:""; 
 $pwd=isset($_POST['pwd'])?$_POST['pwd']:"";
 $email=isset($_POST['email'])?$_POST['email']:"";
 $type=isset($_POST['type'])?$_POST['type']:0;
  $etat=isset($_POST['etat'])?$_POST['etat']:0;
  $sql="UPDATE users SET login='$login',pwd='$pwd',email='$email' ,type='$type' ,etat='$etat' where id='$id'";
$res=mysqli_query($conn,$sql);
if($res){
	echo"les donnees sont modifi&eacute;e.";?>
	
<script>
	setTimeout(function(){
		<?php if($_SESSION['id']==$id)
		   echo'window.location.href="login2.php"';
	    else 
	    	echo 'window.location.href="utilisateur.php"';
	    ?>
	},1500);
</script>
	<?php
}
else {
	echo"erreur de modification";
}
?>