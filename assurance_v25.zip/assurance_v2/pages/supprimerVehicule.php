<?php
require_once("identifier.php");
  session_start();
  if(isset($_SESSION['user'])){

require_once('connexiondb.php');
 $id=isset($_GET['id'])?$_GET['id']:0;

   
 $requete="delete from risque  WHERE id=$id";
 $resultat=mysqli_query($conn,$requete);


 header('location:vehicules.php');
}
else{
  header('location:login2.php');   
}
?>