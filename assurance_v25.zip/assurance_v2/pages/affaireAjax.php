<?php  

        require_once("connexiondb.php");
       $input=strtoupper(isset($_GET['client'])?$_GET['client']:"");
$requet =  "SELECT affaires.id as'id',affaires.datea,affaires.timea,compagnies.mail as'mail1',affaires.police,affaires.numAttest,affaires.type,affaires.ferme,clients.cin as'cin1',risque.matricule as'mat1', affaires.production,affaires.nbrFractions,affaires.duree,affaires.datei,affaires.datef,affaires.solde as'solde',affaires.obs,affaires.etat,affaires.op FROM affaires , clients, risque,compagnies where (clients.id=affaires.client and  risque.id=affaires.risque and compagnies.id=affaires.compagnie) and (UPPER(cin) like'$input%' or UPPER(police) like'$input%' or UPPER(matricule) like'$input%')
order by affaires.id desc";
$requetCount="SELECT count(*) countC FROM affaires,clients,risque where (clients.id=affaires.client and  risque.id=affaires.risque ) and (UPPER(clients.cin) like'$input%' or  UPPER(police) like'$input%' or UPPER(risque.matricule) like'$input%')";
$resultatAffaire = mysqli_query( $conn,$requet) ;  
$resultatCount =mysqli_query( $conn,$requetCount) ;
$tabCount=  mysqli_fetch_array($resultatCount) ;
$nbrAffaire= $tabCount['countC'];
        if(mysqli_num_rows( $resultatAffaire)){
       echo '<table class="table table-striped table-bordered table-responsive tb"><tr><th>Id ['.$nbrAffaire.']</th> <th>dateAssurer</th>  <th>timea</th>  <th>compagnie</th>  <th>police</th> <th>numAttest</th>    
                    <th>type</th>  <th>ferme</th> <th>client</th> <th>risque_matr</th> <th>production</th><th><a href="fractions.php">nFractions</a></th>
                    <th>duree</th>  <th>date_debut</th> <th>date_fin_aff</th><th>solde</th><th>etat</th><th>op</th> <th>obs</th><th>Actions</th>      
                   </tr>';
        while ($affaire=mysqli_fetch_assoc($resultatAffaire)) {
        	$affr=$affaire['id'];
                      $req="SELECT * from fractions where affaire=$affr";
                       $res=mysqli_query($conn,$req);
                     $bgClr=mysqli_num_rows($res)>0?'bg-white':'';
                     $clr=mysqli_num_rows($res)>0?'text-dark':'';
                     $bgClr=$affaire['solde']!=$affaire['production']?'bg-warning':$bgClr;
        	$type=$affaire['type']==1? 'auto':'moto';
 $ferme=$affaire['ferme']==1? 'ouvert':'ferme';
 $et=$affaire['etat'];
          if($et==1)
            $etat="active";
          else if($et==0)
            $etat="complet";
          else $etat="annuler";
          
          echo '<tr class="'.$clr.' '.$bgClr.'"> <td>'. $affaire["id"].' </td> <td> '.$affaire["datea"].' </td><td>'. $affaire["timea"] .'</td> <td><a href="compagnie.php?nameC='. $affaire["mail1"].'">'. $affaire["mail1"].' </a></td> <td> '.$affaire["police"].' </td><td>'. $affaire["numAttest"] .'</td> <td>'. $type.' </td> <td> '.$ferme.' </td><td> <a href="clients.php?cin='. $affaire["cin1"] .'">'. $affaire["cin1"] .'</a></td> <td><a href="vehicules.php?matricule='. $affaire["mat1"].'">'. $affaire["mat1"].'</a></td> <td> '.$affaire["production"].' </td> <td><a href="fractions.php?fraction='.$affaire["police"].'">'.$affaire["nbrFractions"].' fractions</a></td><td>'. $affaire["duree"].' mois' .'</td> <td>'. $affaire["datei"].' </td> <td> '.$affaire["datef"].' </td><td> '.$affaire["solde"].' DH'.' </td><td> '.$etat.' </td><td><a href="utilisateur.php?loginU='.$affaire["op"].'">'.$affaire["op"].'</a> </td><td> '.$affaire["obs"].' </td><td>';
          if($affaire['solde']==$affaire['production'] ){
                            echo '<a  href="editerAffaire.php?id='.$affaire["id"].' " ><span class="fa fa-edit"></span></a> 
                              &nbsp';
                        echo' <a onclick="return confirm(\'vous etes sur de supp?\')"
                        href="supprimerAffaire.php?id='.$affaire["id"].' " ><span class="fa fa-trash"></span></a>
                           ';
                       }
                    
        }
         echo "</tr></table>";
      
      
      }
      else echo '&nbsp &nbsp &nbsp aucune affaire trouv&eacute;.';

?>