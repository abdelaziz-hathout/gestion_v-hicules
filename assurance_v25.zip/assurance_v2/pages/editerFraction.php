<?php
 require_once("identifier.php");
 
 require_once ("connexiondb.php");
 $id=isset($_GET['id'])?$_GET['id']:0;
 $sql="SELECT * from fractions where id='$id' ";
 $res=mysqli_query($conn,$sql);
 $rows=mysqli_fetch_assoc($res);
 $affaire=$rows['affaire'];
 $montant=$rows['montant'];
 $date_effet=$rows['date_effet'];
 $date_reg=$rows['date_reg'];
 $solde=$rows['solde'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>edit fractions</title>
	<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
	?>
<div class="container col-lg-4 col-lg-offset-3">
	<div class="util" >
	<div class="card margetop60">
		<div class="card-header bg-info text-white">
		modifier une fractions</div>
	    <div class="card-body text-info bg-light">
	    	<form method="post" action="updateFraction.php" class="form" >

 			<div class="form-group">
 				<label>id: <?php echo $id?></label>
 					<input type="hidden" name="id" class="form-control" autocomplete="off"  value="<?php echo $id ?>">&nbsp &nbsp &nbsp &nbsp
 					<label >affaire: <?php echo $affaire?></label >
 			   <input type="hidden" name="affaire"class="form-control"autocomplete="off"required value="<?php echo $affaire ?>"></input>
 			   <br><br>
 				<label>montant en DH:
 					<input type="number" name="montant" class="form-control" autocomplete="off" required value="<?php echo $montant ?>" readonly></label>
 					<label >date_effet:
 			   <input type="date" name="date_effet"class="form-control"autocomplete="off"required  value="<?php echo $date_effet ?>" readonly></input>
 			   </label>
 			   <label>date_reg:
 					<input type="date" name="date_reg"class="form-control" autocomplete="off" required value="<?php echo $date_reg ?>"></label> 
          <label>solde:
          <input type="text" name="solde"class="form-control" autocomplete="off" required value="<?php echo $solde ?> "></label> 
 					<br>
                <div class="err">
                	<?php 
                	if(isset($_POST['sub3']))
                     require("updateFractions.php");
                	?>
                </div>	
 					<button type="reset" name="reset"class="btn btn-danger" >
 						<i class="fa fa-remove"></i> &nbsp reset
 					</button> 
          <button type="submit" name="sub3"class="btn btn-success" >
            <i class="fa fa-save"></i> &nbsp Enregistrer
          </button>&nbsp &nbsp
 					<a href="javaScript:history.back()" id="rt">retour </a>
 			</div>
  </div></div>

</div></div>
<?php
include 'footer.php';
?>
</body>
</html>