<?php
    require_once("identifier.php");
    require_once("connexiondb.php");
       $size=isset($_GET['size'] ) ?$_GET['size']: 10;     //nbr limite qui affiche dans la page
        $page=isset($_GET['page'] ) ?$_GET['page']: 1;
        $offset= ($page-1)*$size ; 

        $dateA=strtotime(date('Y-m-d'));
      $requet ="SELECT fractions.id as'id',fractions.affaire as'affaire',clients.cin as'cin',risque.matricule as'matricule',affaires.police as'police',affaires.id as'idF',fractions.montant,fractions.date_effet,fractions.date_reg,fractions.solde as'solde',fractions.obs as'obs'FROM fractions,clients,risque,affaires where (affaires.client=clients.id and affaires.risque=risque.id and affaires.id=fractions.affaire) and (UNIX_TIMESTAMP(fractions.date_effet) <= $dateA and fractions.solde!=0) 
       order by fractions.date_effet desc limit $size 
      offset $offset";
      $requetCount="SELECT count(*) countF from fractions, clients, risque, affaires where (affaires.client=clients.id and affaires.risque=risque.id and affaires.id=fractions.affaire) and (UNIX_TIMESTAMP(fractions.date_effet) <= $dateA and fractions.solde!=0)";
        $resultatFraction = mysqli_query($conn,$requet) ;  
       
        $resultatCount = mysqli_query($conn,$requetCount) ;
        if($resultatCount)
        $tabCount =  mysqli_fetch_assoc($resultatCount) ;
        $nbrFraction = $tabCount['countF'];
        $rest = $nbrFraction%$size; 
         if($rest===0)
          $nbrPage=$nbrFraction/ $size;
          else
          $nbrPage= floor($nbrFraction / $size) +1; 
       
      ?>
<!DOCTYPE HTML>
 <html>
    <head>
      <meta charset="utf-8">
      <title>Paiment</title>
    <?php require("styleLinks.php");?>
    </head>
       <body>
           <?php
            include("header.php");
             ?>
            
         <div class="container col-lg-8 col-md-12 col-sm-12">
           
             <div class="card  "> 
      
            <div class="card-header bg-primary">Liste des fractions  [<?php echo $nbrFraction ?>  fractions] </div>
            
              <div class="card-body text-info bg-light ">
              <?php  if(mysqli_num_rows($resultatFraction)>0){ ?>
                <div id="fraction2">
                <table class="table table-striped table-bordered table-responsive tb2">
                  <thead >
                   <tr>
                    <th><a href="affaires.php" title="affaires">Id</a></th> 
                    <th>client</th>
                    <th>risque</th>
                    <th>police</th>
                    <th>montant</th>  
                    <th>date_effet</th> 
                     <th>solde</th> 
                     <th >observation</th>              
                   </tr>
                  </thead>
                  <tbody>
                    <?php 
                    while($fraction = mysqli_fetch_array($resultatFraction)) { 
                      $idF=$fraction['idF'];
                      $id=$fraction['id'];
                    
                      ?>
                          <tr >
                            <td> <?php echo $fraction['id'] ?> </td>
                            <td> <a href="clients.php?cin=<?php echo $fraction['cin'] ?>"><?php echo $fraction['cin'] ?></a></td>
                            <td> <a href="vehicules.php?matricule=<?php echo $fraction['matricule'] ?>"><?php echo $fraction['matricule'] ?></a> </td>
                            <td><a href="affaires.php?client=<?php echo $fraction['police'] ?>"> <?php echo $fraction['police'] ?> </a></td>
                            <td> <?php echo $fraction['montant'] ?> </td>
                            <td> <?php echo $fraction['date_effet'] ?> </td>
                            <td> <?php echo $fraction['solde'] ?> </td>
                            <td ><textarea name="obs" id="obs" readonly> <?php echo $fraction['obs'] ?> </textarea> <br>
                              <a href="editObsF.php?id=<?php echo $fraction['id'] ?>" > <i class="fa fa-edit"></i> </a>&nbsp &nbsp &nbsp &nbsp
                              <a href="supprimerObsF.php?id=<?php echo $fraction['id'] ?>" > <i class="fa fa-trash"></i> </a>
                            </td>
                          
                          </tr>
                         
                    <?php   } ?>
                  </tbody>

                </table>
                </div>
                <?php ;}
                 else echo'&nbsp &nbsp &nbsp aucune fraction trouv&eacute;e.'; 
                 ?>
                    <div >
                       <ul class="pagination ">
                        <?php
                        for($i=1;$i<=$nbrPage;$i++){ ?>
                          
                         <li class="<?php if($i == $page) echo'active' ?> page-item"> <a href="paiement.php ?page=<?php echo $i;?>" class="page-link">  <?php echo $i;?>  </a> </li> 

                       <?php   } ?>
                       
                        </ul>
                    </div>
                     <a href="javaScript:history.back()" id="rt">retour </a>
               </div>
           </div>
     </div>
  
 </body>
       


<footer>
  

<?php
            include("footer.php");
             ?>
</footer>


 </html>