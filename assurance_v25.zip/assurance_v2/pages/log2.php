<?php
  SESSION_START();
 require_once ("connexiondb.php");
  $login = $_POST['login'];
  $pwd = $_POST['pwd'];
  $check = $_POST['check'];
    $a=0;
     $sql1="SELECT * from users where login='$login' and pwd='$pwd' " ;
     
         $result = mysqli_query($conn, $sql1);

   if($result){
         $users = mysqli_fetch_assoc($result);
      if($users){
         $_SESSION['id']=$users['id']; 
         $_SESSION['user']=$users['login'];
         $_SESSION['pwd']=$users['pwd'];
         $_SESSION['email']=$users['email'];
         $_SESSION['type']=$users['type'];
         $_SESSION['etat']=$users['etat'];
         $_SESSION['check']=$check;
         if($_SESSION['etat']==1){
          $_SESSION['erreur']="";
         header("location:home.php");
            }
        else {
           $_SESSION['erreur']="votre compte est d&eacute;sactiver veuillez contacter l'administrateur.";
           header("location:login2.php");
           
         }
       }
     
       else { 
        $_SESSION['erreur']="name or password incorrect!";
         header("location:login2.php");
         
        }
   
          }
    
     ?>
      
    