<?php
require_once("identifier.php");
require_once("connexiondb.php");

$id=isset($_GET['id'] ) ?$_GET['id']:0;


$req="UPDATE affaires set obs='' where id=$id";
$res=mysqli_query($conn,$req);

	header('location:renouvellement.php');