
<?php
require_once("identifier.php");
require_once "connexiondb.php";
 

?>
<!DOCTYPE HTML>
<html>
<head>

  <meta charset="utf-8">
  <title>Nouvelle Affaire</title>
  <?php require("styleLinks.php");

  $idC=isset($_POST['clt']) ?$_POST['clt']:0;
  $queryC="SELECT * from clients where id='$idC'";
  $resC=mysqli_query($conn,$queryC);
  $rowC=mysqli_fetch_assoc($resC);
  $idR=isset($_POST['risque']) ?$_POST['risque']:0;
  $queryR="SELECT * from risque where id='$idR'";
  $resR=mysqli_query($conn,$queryR);
  $rowR=mysqli_fetch_assoc($resR);
  $idCmp=isset($_POST['cmp']) ?$_POST['cmp']:0;
  $queryCmp="SELECT * from compagnies where id='$idCmp'";
  $resCmp=mysqli_query($conn,$queryCmp);
  $rowCmp=mysqli_fetch_assoc($resCmp);
  $user=$_SESSION['email'];
  ?>
  

</head>
<body>

 <?php 
 require_once("identifier.php");

 include("header.php"); ?>


 <div class="container  col-lg-8 col-lg-offset-3 col-md-10 col-md-offset-1 col-sm-12 col-sm-offset-0">
     <?php
              if(isset($_POST['save'])){ ?>
     <div class="alert alert-danger">
              <?php
               require 'insertAffaire.php';       
           ?>
          </div>
      <?php } ?>
   <div class="card margetop60 cltcmp"> 

    <div class="card-header bg-primary">Saisir les données d'Affaire</div>
    
    <div class="card-body text-info bg-light">
            
      <form method="post" action="nouvelleAffaire.php" class="form">

        <div id="cltcmp"class="form-group form-inline ">
             Clients:
          <select  name="clt" class="form-control"  id="select">
            <option value="<?php echo $rowC['id'] ?>" class="default" selected ><?php  if(isset($rowC)) echo $rowC['nom'].' : '.$rowC['cin'] ?></option>
           
             <?php  require_once "connexiondb.php";
             $req="select * from clients ";
             $res=mysqli_query($conn,$req);
             while($clients=mysqli_fetch_assoc($res)){?>
                <option value="<?php echo $clients['id']?>" ><?php echo $clients['nom']. ' : '.$clients['cin']?></option>
            <?php }?>
        </select>
         &nbsp &nbsp
        <label for=""> 
           CIN: 
           <input type="text" name="cin" placeholder="taper cin"  id="cin01"  class="form-control" ></label>
             &nbsp &nbsp 
           <select  name="cmp" class="form-control"  id="select2">
             <option value="<?php echo $rowCmp['id'] ?>" class="default" selected ><?php if(isset($rowCmp)) echo $rowCmp['nom'].' : '.$rowCmp['mail']; ?></option>
             <?php  require_once "connexiondb.php";
             $req1="select * from compagnies ";
             $res1=mysqli_query($conn,$req1);
             while($compagnies=mysqli_fetch_assoc($res1)){?>
                <option value="<?php echo $compagnies['id']?>"><?php echo $compagnies['nom'].' : '.$compagnies['mail'];?></option>
            <?php }?>
          </select>&nbsp &nbsp
           <a href="javaScript:history.back()" id="rt">retour </a>
          </div>
          <div id="hide1">
           <table class="table table-responsive table-bordered" >
            <tr>
            <td>
         <div class="form-group ">
         <label >datea:
         <input type="date"
         name="datea" required 
         placeholder="date"
         class="form-control " value="<?php echo date('Y-m-d')?>" /></label>
         </td>
         <td>
         <label >time:
         <input type="time"
         name="timea"  required value="<?php echo date('H:i')?>" 
         placeholder="time" 
         class="form-control"/></label>
         </td>
         <td>
         <label >police:
         <input type="text "  
         name="police" readonly
         placeholder="Taper un police" 
         class="form-control" id="police"  required value="<?php 
         include'connexiondb.php';
         do{
             $str='ABCDEFGHIJKLMNOPQRSTUVYXYZ';
             $str1='0123456789';
             $rand=substr(str_shuffle($str),-4);
             $rand.=substr(str_shuffle($str1),-4);
             $query="SELECT * from affaires where police='$rand' or numAttest='$rand'";
             $res=mysqli_query($conn,$query);
           }
         while(mysqli_num_rows($res)>0);
         echo $rand;
        ?>" /></label>

         </td>
         </tr>

         <tr>
           <td>
            type:
            <select name="type"class="form-control " id="select3" >
                <option value="1" selected>auto</option>
                <option value="0">moto</option>
            </select>
        </td>
        <td>
            ferme
            <select name="ferme"class="form-control " id="select4">
                <option value="0">ferme</option>
                <option value="1" selected>ouvert</option>
            </select>
        </td>
        <td>
            matricule:
            <select name="risque"class="form-control " id="select5">
             <?php  require_once "connexiondb.php";
             $req2="select * from risque ";
             $res2=mysqli_query($conn,$req2);
             while($risque=mysqli_fetch_assoc($res2)){?>
                <option value="<?php echo $risque['id']?>"><?php echo $risque['matricule']?></option>
            <?php }?>
        </select>
    </td>
</tr>

          <tr>
         <td>
        <label for="obs">obs:
        <input type="text"
        name="obs"  value="" minlength="3"pattern="^([a-zA-Z]){3,}([\w\s])*"
        placeholder="ajouter une remarque" 
        class="form-control"/></label>
         </td>
        <td>
        <label >nbr de fractions:
        <input type="number"step="any" min="1" max="12"
        name="nbrFractions" value="1" 
        class="form-control"/></label>
        </td>
        <td>
        <label >op:
        <input type="text " readonly
        name="op" value="<?php echo $user;?>" 
        class="form-control"/></label>
        </td>
         </tr>
          <tr>
         <td>
        duree:
         <select name="duree" class="form-control  date1" id="duree" required>
             <option value="1" selected>1 mois</option>
             <option value="3">3 mois</option>
             <option value="6">6 mois</option>
             <option value="12">12 mois</option>
             
         </select>
         </td>
         <td>
        <label for="datei">datei:
        <input type="date"
        name="datei" id="datei" required
        value="<?php echo date('Y-m-d')?>" 
        class="form-control date1"/></label>
        </td>
         <td>  
        <label for="datef">datef:
        <input type="date" name="datef" id="datef" readonly
        value="<?php echo date('Y-m-d',strtotime("+30 days"))?>"
        class="form-control datef"/>
        </label>
        </td>
         </tr>
          <tr>
        <td>
        <label for="production">production:
        <input type="number" step="any" min="0"
        name="production"  required id="prod" 
        placeholder="Taper un production" 
        class="form-control"/></label>
        </td>
         <td>
        <label for="solde">solde en DH:
        <input type="number" step="any" min="0"
        name="solde" readonly  id="solde"  
        class="form-control"/></label>
        </td>
        
         <td>
         etat:
         <select name="etat" class="form-control col-lg-12 date1" id="etat">
             <option value="1" selected>active</option>
             <option value="0">complet</option>
             <option value="-1">annuler</option>
         </select>
         </td>
          </tr>
          <tr>
         <td>
         <label for="provision">numAttest:
         <input type="text"
         name="numAttest" required readonly
         placeholder="numero d'attestation" value="<?php 
         include'connexiondb.php';
         $query="SELECT numAttest from affaires";
         $res=mysqli_query($conn,$query);
         $num=mysqli_fetch_assoc($res);
           do{
             $str='ABCDEFGHIJKLMNOPQRSTUVYXYZ';
             $str1='0123456789';
             $rand=substr(str_shuffle($str),-4);
             $rand.=substr(str_shuffle($str1),-4);
             $query="SELECT * from affaires where numAttest='$rand' or police='$rand'";
             $res=mysqli_query($conn,$query);
           }
         while(mysqli_num_rows($res)>0);
         echo $rand;

        ?>"     
         class="form-control"/></label>
          </td>
         </tr>
          </table>
         
        <button type="reset" name="reset" class="btn btn-danger">
          <span class="fa fa-remove"></span> 
          Reset 
        </button>
         <button type="submit" name="save" class="btn btn-success" >
          <span class="fa fa-save"></span> 
          Save
        </button>&nbsp &nbsp
        
        </div>
      </div>

    </form>
  </div>
</div>
</div>
</div>

</body>



</html> 
 <?php
  include("footer.php");
  ?>