
 <div class="esc"></div>
 <div class="toggle">
 <div class="foot ">
			<div class="info">
				<table class="table table-sm">
					<tr>
						<td>
							&copy; MORITSOFT
						</td>
						<td>
							<i class="fa fa-phone fa-rotate-90"></i>  0767276367
						</td>
					</tr>
					<tr>
						<td>
							<i class="fa fa-globe"></i>  Https://www.moritsoft.com
						</td>
						<td>
							<i class="fa fa-envelope"></i>  moritsoft@gmail.com
						</td>
					</tr>
				</table>
			</div>
		</div>

  </div>
