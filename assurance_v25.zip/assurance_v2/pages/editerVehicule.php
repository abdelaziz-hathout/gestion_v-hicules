
<?php
require_once("identifier.php");

require_once('connexiondb.php');
$id=isset($_GET['id'])?$_GET['id']:0;
$requete="select * from risque where id='$id'";
$resultat=mysqli_query($conn,$requete);
$risque=mysqli_fetch_assoc($resultat); 

$marque=$risque['marque'];
$matricule=$risque['matricule'];

?>

<!DOCTYPE HTML>
<html>
<head>

  <meta charset="utf-8">
  <title>modifier une Risque</title>
  <?php require("styleLinks.php");?>

</head>
<body>
 <?php   include("header.php"); ?>

 <div class="container  col-lg-4 col-lg-offset-3 col-md-8 col-md-offset-2">

   <div class="card margetop60"> 

    <div  class="card-header bg-primary"> Modifier Risque</div>
    
    <div class="card-body text-info bg-light">

      <form method="post" action="editerVehicule.php" class="form" id="veh">
        <div class="form-group">
         <label for="id">Id: <?php echo $id?>
         <input type="hidden"
         name="id"
         class="form-control"
         value="<?php echo $id ?> "/></label><br>

         <label for="marque">Marque:</label>
         <input type="text "
         name="marque"minlength="3"
         placeholder="Taper un Marque" pattern="^([a-zA-Z_-]){3,}" 
         class="form-control" id="marque"
         value="<?php echo $marque ?> "/>
         <div id="errM"></div>
         <label for="matricule">Matricule:</label>
         <input type="text "
         name="matricule"
         placeholder="Taper un Matricule" 
         class="form-control"
         value="<?php echo $matricule ?> "/>
          <?php
            if(isset($_POST['submit3']))
              include("updateVehicules.php");
          ?><br>
        <button  name="reset3" type="reset" class="btn btn-danger" >
          <span   class="fa fa-remove"></span> 
          reset
        </button> 
        <button  type="submit" name="submit3"class="btn btn-success" >
          <span  name="update" class="fa fa-save"></span> 
          Update
        </button>
       &nbsp &nbsp
       <a href="javaScript:history.back()" id="rt">retour </a>
      </div>
    </form>
  </div>
</div>

</div>


</body>

<footer>

  <?php
  include("footer.php");
  ?>
</footer>

</html> 