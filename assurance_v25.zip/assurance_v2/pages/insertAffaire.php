<?php

require_once("identifier.php");
require_once('connexiondb.php');

 $datea=isset($_POST['datea'])?$_POST['datea']:"";
 $timea=isset($_POST['timea'])?$_POST['timea']:"";
 $compagnie=isset($_POST['cmp'])?$_POST['cmp']:"";
 $police=isset($_POST['police'])?$_POST['police']:"";

 $type=isset($_POST['type'])?$_POST['type']:"";
 $ferme=isset($_POST['ferme'])?$_POST['ferme']:"";
 $client=isset($_POST['clt'])?$_POST['clt']:"";
 $risque=isset($_POST['risque'])?$_POST['risque']:"";
 $production=isset($_POST['production'])?$_POST['production']:"";

 $duree=isset($_POST['duree'])?$_POST['duree']:0;
 $datei=isset($_POST['datei'])?$_POST['datei']:"";
 $datei=date('Y-m-d',strtotime($datei));
 $datef=isset($_POST['datef'])?$_POST['datef']:"";
 $solde=isset($_POST['solde'])?$_POST['solde']:$production;
 $obs=isset($_POST['obs'])?$_POST['obs']:"";
 $etat=isset($_POST['etat'])?$_POST['etat']:"";
 $op=isset($_POST['op'])?$_POST['op']:$_SESSION['email'];
  $datea=date('Y-m-d',strtotime($datea));
  $timea=date('H:i:s',strtotime($timea));
  $datei=date('Y-m-d',strtotime($datei));
  $datef=date('Y-m-d',strtotime($datef));

 $nbrFractions=isset($_POST['nbrFractions'])?$_POST['nbrFractions']:"";
 $numAttest=isset($_POST['numAttest'])?$_POST['numAttest']:"";

 $requete="INSERT into affaires(datea,timea,compagnie,police,type,ferme,client,risque,production,duree,
 datei,datef,solde,obs,etat,op,nbrFractions,numAttest)
 values ('$datea','$timea','$compagnie','$police','$type','$ferme','$client','$risque','$production','$duree',
 '$datei','$datef','$solde','$obs','$etat','$op','$nbrFractions','$numAttest')";

 $resultat=mysqli_query($conn,$requete);

  if($resultat){
    echo"les donn&eacute;es sont ins&eacute;r&eacute;es.<br>";
    $id_Affaire=mysqli_insert_id($conn);
    $a=$duree/$nbrFractions;
    $a=floor($a*30);
    for($x=1,$n=0;$x<=$nbrFractions;$x++,$n+=$a){
      $affaire=$id_Affaire;
      $montant = $solde/$nbrFractions;
      $dat=$datei."+".$n." days";
      $date_effet=date('Y-m-d',strtotime($dat));
      $requete="insert into fractions (affaire,montant,date_effet,solde)
      values ('$affaire','$montant','$date_effet','$montant')";
      $resultat=mysqli_query($conn,$requete);
    }
}
else 
 echo "erreur".mysqli_error($conn);

 echo '<script> setTimeout(function(){window.location.href="affaires.php?"},1500); </script>';


?>