<?php
 require_once("identifier.php");
 
 require_once ("connexiondb.php");

 $idA=isset($_GET['idA'])?$_GET['idA']:0; 
 $id=isset($_GET['id'])?$_GET['id']:0;
 echo $id;
 $sql="SELECT * from reglement where id='$id' ";
 $res=mysqli_query($conn,$sql);
 $rows=mysqli_fetch_assoc($res);
 $fraction=$rows['fraction'];
 $montant=$rows['montant'];
 $datea=$rows['datea'];
 $mode=$rows['mode'];
 $ref=$rows['ref'];
 $validation=$rows['validation'];

?>
<!DOCTYPE HTML>
<html>
<head>

  <meta charset="utf-8">
  <title>Nouvelle reglement</title>
 <?php require("styleLinks.php");?>


</head>
<body>

 <?php 
 require_once("identifier.php");

 include("header.php"); ?>


 <div class="container col-lg-4 col-lg-offset-3 col-md-8 col-md-offset-2">



   <div class="card "> 

    <div class="card-header bg-primary">modifier reglement</div>
    
    <div class="card-body text-info bg-light">


      <form method="post" action="updateReglement.php" class="form">
       <div class="form-group ">

        <input type="hidden"
         name="affaire"
          value="<?php echo $idA ?>" 
         class="form-control"/>

         <input type="hidden"
         name="id"
          value="<?php echo $id ?>" 
         class="form-control"/>

         <input type="hidden"
         name="oSolde"
          value="<?php echo $montant ?>" 
         class="form-control"/>

         <label for="fraction">fraction:
         <input type="text"
         name="fraction" required
         placeholder="Taper une fraction" value="<?php echo $fraction ?>" 
         class="form-control"/></label>

         <label for="montant">montant:
         <input type="number"
         name="montant"  required
         placeholder="Taper un montant" value="<?php echo $montant ?>" 
         class="form-control"/></label>

         <label >datea:
         <input type="datea"
         name="datea" disabled
         value="<?php echo date('Y-m-d') ?>" 
         class="form-control"/></label>

         <label for="mode">mode:
         <input type="text"
         name="mode"  required
         placeholder="Taper un mode" value="<?php echo $mode ?>" 
         class="form-control"/></label>

         <label for="ref">ref:
         <input type="text"
         name="ref"  required value="<?php echo $ref ?>" 
         placeholder="Taper un ref" 
         class="form-control"/></label>

         <label for="validation">validation:
         <input type="number"
         name="validation" required
         placeholder="Taper un validation" value="<?php echo $validation ?>" 
         class="form-control"/></label>
         <br><br>
         <div class="err">
         	<?php if(isset($_POST['save']))
                 require 'insertReglement.php';
         	?>
         </div>
         <button type="reset" name="reset" class="btn btn-danger">
          <span class="fa fa-remove"></span> 
          Save
        </button>
        <button type="submit" name="save" class="btn btn-success" value="save">
          <span class="fa fa-save"></span> 
          Save
        </button>&nbsp &nbsp
       <a href="javaScript:history.back()" id="rt">retour </a>
        
      </div>
    </form>
  </div>
</div>

</div>


</body>

<footer>

  <?php
  include("footer.php");
  ?>
</footer>

</html> 