<?php
require_once("identifier.php");

require_once('connexiondb.php');
 $soldeF=isset($_POST['soldeF'])?$_POST['soldeF']:0;
 $soldeA=isset($_POST['soldeA'])?$_POST['soldeA']:0;
 $affaire=isset($_POST['affaire'])?$_POST['affaire']:0;
 $validation=isset($_POST['validation'])?$_POST['validation']:0;
 $fraction=isset($_POST['fraction'])?$_POST['fraction']:0;
 $montant=isset($_POST['montant'])?$_POST['montant']:0;
 $datea=isset($_POST['datea'])?$_POST['datea']:date('Y-m-d');
 $mode=isset($_POST['mode'])?$_POST['mode']:0;
 $ref=isset($_POST['ref'])?$_POST['ref']:"";
 $datea=date('Y-m-d',strtotime($datea));
 $requete="INSERT into reglement(fraction,montant,datea,mode,ref,validation)
 values ('$fraction','$montant','$datea','$mode','$ref','$validation')";
 $resultat=mysqli_query($conn,$requete);
 $nSoldeF=$soldeF-$montant;
 $nSoldeA=$soldeA-$montant;
 
 $req="UPDATE fractions set solde='$nSoldeF', date_reg='$datea' where id=$fraction";
 $res=mysqli_query($conn,$req); 
 $req1="UPDATE affaires set solde='$nSoldeA' where id=$affaire";
 $res1=mysqli_query($conn,$req1);


echo '<script> window.location.href="reglerAffaire.php?id='.$affaire.'"; </script>';

 
?>