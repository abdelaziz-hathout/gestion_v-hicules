<?php
require_once("identifier.php");

require_once('connexiondb.php');

 $marque=isset($_POST['marque'])?$_POST['marque']:"";
 $matricule=isset($_POST['matricule'])?$_POST['matricule']:"";


   
 $requete=" insert into risque (marque,matricule)
 values ('$marque','$matricule')";
 $resultat=mysqli_query($conn,$requete);

 header('location:vehicules.php');


?>