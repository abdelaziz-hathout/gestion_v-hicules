<?php
 require_once("identifier.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Reglage</title>
	<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
	?>
<div class="container">
	reglage
</div>

<?php
     include("footer.php");
	?>
</body>
</html>