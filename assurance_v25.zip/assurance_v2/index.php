<?php
 header("location:pages/home.php");
?>