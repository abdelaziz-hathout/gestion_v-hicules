      <?php
  require_once("identifier.php");

        require_once("connexiondb.php");

        
       $size=isset($_GET['size'] ) ?$_GET['size']: 20;     //nbr limite qui affiche dans la page
        $page=isset($_GET['page'] ) ?$_GET['page']: 1;
        $offset= ($page-1)*$size ;  //nbr de sauter
//récuperer une parametre envoyer par la methode GET
      $cinC=strtoupper(isset($_GET['cin'])?$_GET['cin']:'');
      $requet = "SELECT clients.id,clients.nom,clients.cin,clients.contact,clients.adresse,clients.ville,clients.cp,clients.tel,clients.fax,clients.ice,clients.mail,clients.activite,clients.obs,clients.pays,mandataires.cin as'cin1' FROM clients left outer join mandataires on (clients.mandataire=mandataires.id) where UPPER(clients.cin) like'$cinC%'
       order by clients.id desc limit $size 
      offset $offset";
      $requetCount="SELECT count(*) countC from clients where UPPER(clients.cin) like'$cinC%'";
      //la fct query() pour execut la requet SELECT
     
      $resultatClient = mysqli_query( $conn,$requet) ;  
        $resultatCount =mysqli_query( $conn,$requetCount) ;
        $tabCount=  mysqli_fetch_array($resultatCount) ;
        $nbrClient= $tabCount['countC'];
        $rest= $nbrClient%$size;  //rest de la division 
         if($rest===0)
          $nbrPage=$nbrClient / $size;
          else
          $nbrPage= floor($nbrClient / $size) +1; //la partie reel plus 1
      ?>
 
<!DOCTYPE HTML>
 <html>
    <head>
      
      <meta charset="utf-8">
      <title>Gestion des clients</title>
     <?php require("styleLinks.php");?>
     
    <!--  <link rel="stylesheet" href="../fonts/bootstrap.min.css"> -->
    </head>
       <body>
           

           <?php
            include("header.php");
             ?>
        <!-- intégrer notre panneau aux milieu de la page !-->
         <div class="container col-lg-12 col-md-12 col-sm-12">
        <!-- panneau de recherche--> 
            <div class="card  margetop60"> 
       <!-- intégrer la partie de recherche !-->
    
            <div class="card-header bg-success">
            
               Chercher et Ajouter des clients
             </div>
        <!--intégrer le contenu de recherche !-->
              <div class="card-body text-info bg-light">
                <form method="get" class="form-inline">
                 <div class="form-group">
              
                  <input type="text"
                   name="cin" value="<?php echo $cinC ?>" 
                    id="cin1" autocomplete="off"
                    placeholder=" chercher par cin, email or tel" 
                    class="form-control inp"
                    >
               
                &nbsp &nbsp &nbsp &nbsp 
                        <a  href="nouveauClient.php ">
                         <span class="fa fa-plus"></span>
                            AjoutClient
                        </a>
                         </div>
                </form>
             </div>
          </div>
     <!--------------------------------------------------------- -->

        <!-- panneau du contenu de l'interface-->
       
             <div class="card "> 
      
            <div class="card-header bg-primary">Liste des clients  [<?php echo $nbrClient ?>  Clients] </div>
            
              <div  class="card-body text-info bg-light">
                 <div id="res2">
                <table  class="table table-striped table-bordered table-responsive tb">
                  <thead >
                   <tr>
                    <th>Id [<?php echo $nbrClient ?>]</th> <th>Nom</th>  <th>CIN</th>  <th>Contact</th>  <th>Adress</th> <th>Ville</th>    
                    <th>Cp</th>  <th>Tel</th> <th>Fax</th> <th>Ice</th> <th>Email</th><th>Activite</th>
                    <th>Obs</th>  <th>Pays</th> <th><a href="mandataires.php" title="listes des mandataires">Mandataires</a></th> <th>Action</th>      
                   </tr>
                  </thead>
                  <tbody >
                    <?php while($client = mysqli_fetch_array($resultatClient)) { 

                     $idClt=$client['id'];
                     $req="SELECT * from affaires where client=$idClt";
                     $res=mysqli_query($conn,$req);
                     $bgClr=mysqli_num_rows($res)>0?'bg-danger':'';
                     $clr=mysqli_num_rows($res)>0?'text-white':''; 
                      ?>
                       
                   
                          <tr class="<?php echo $bgClr.' '.$clr;  ?>">
                            <td> <?php echo $client['id'] ?> </td>
                            <td> <?php echo $client['nom'] ?> </td>
                            <td> <?php echo $client['cin'] ?> </td>
                            <td> <?php echo $client['contact'] ?> </td>
                            <td> <?php echo $client['adresse'] ?> </td>
                            <td> <?php echo $client['ville'] ?> </td>
                            <td> <?php echo $client['cp'] ?> </td>
                            <td> <?php echo $client['tel'] ?> </td>
                            <td> <?php echo $client['fax'] ?> </td>
                            <td> <?php echo $client['ice'] ?> </td>
                            <td> <?php echo $client['mail'] ?> </td>
                            <td> <?php echo $client['activite'] ?> </td>
                            <td> <?php echo $client['obs'] ?> </td>
                            <td> <?php echo $client['pays'] ?> </td>
                            <td> <a  href="mandataires.php?cin=<?php echo $client['cin1'] ?>" ><?php echo $client['cin1'] ?></a> </td>
                            <td>
                             
                            <a  href="editerClient.php?id=<?php echo $client['id'] ?>" method="get"> <span class="fa fa-edit"></span></a> 
                              &nbsp
                              <?php if($bgClr!='bg-danger'){ ?>
                         <a id="supp"onclick="return confirm('vous etes sur de supp?')"
                        href="supprimerClient.php?id=<?php echo $client['id'] ?>" >  <span class="fa fa-trash"></span></a>
                             <?php  } ?>
                           </td>
                          </tr>
                          <?php  } ?>

                  </tbody>
                </table>
                    </div>
                      <div >
                       <ul class="pagination ">
                        <?php
                        for($i=1;$i<=$nbrPage;$i++){ ?>
                          
                         <li class="<?php if($i == $page) echo'active' ?> page-item"> <a  class="page-link"href="clients.php?page=<?php echo $i;?>">  <?php echo $i;?>  </a> </li> 

                       <?php   } ?>

                        </ul>
                    </div>
                <a href="javaScript:history.back()" id="rt">retour </a>
               </div>
           </div>
     </div>
  
 </body>
       


<footer>
  

<?php
            include("footer.php");
             ?>
</footer>


 </html>