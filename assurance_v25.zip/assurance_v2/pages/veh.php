<?php  

        require_once("connexiondb.php");
        $mat=isset($_POST['matricule'] ) ?$_POST['matricule']:"";
        $mat=strtoupper($mat);
       $requet =  "SELECT * FROM risque where UPPER(matricule) like'$mat%' order by id desc";
       $requetCount="SELECT count(*) countR from risque where UPPER(matricule) like'$mat%'";
        $resultatCount =mysqli_query( $conn,$requetCount) ;
        $tabCount=  mysqli_fetch_array($resultatCount) ;
        $nbrRisque= $tabCount['countR'];
       $resultatRisque = mysqli_query($conn,$requet) ; 
       if(mysqli_num_rows($resultatRisque)>0){
       echo '<table class="table table-striped tabble-border table-responsive tb"><tr> <th>Id ['.$nbrRisque.'] </th><th>Marque</th><th>Matricule</th><th>Actions</th> </tr>';
        while ($risque=mysqli_fetch_assoc($resultatRisque)) {

          $idR=$risque['id'];
                     $req="SELECT * from affaires where risque=$idR";
                     $res=mysqli_query($conn,$req);
                     $bgClr=mysqli_num_rows($res)>0?'bg-danger':'';
                     $clr=mysqli_num_rows($res)>0?'text-white':''; 

          echo '<tr class="'.$clr.' '.$bgClr.'"> <td>'. $risque['id'].' </td> <td> '.$risque['marque'].' </td><td>'. $risque['matricule'] .'</td> <td>
                            <a  href="editerVehicule.php?id='.$risque["id"].' " ><span class="fa fa-edit"></span></a> 
                              &nbsp';
                           if($bgClr!="bg-danger"){
                          echo'
                         <a onclick="return confirm(\'vous etes sur de supp?\')"
                        href="supprimerVehicule.php?id='.$risque["id"].' " ><span class="fa fa-trash"></span></a>';
                      }
                           echo'</td>';
        }
        echo "</tr></table>";
      
      }

      
      else echo '&nbsp &nbsp aucune risque trouv&eacute;e.';

?>