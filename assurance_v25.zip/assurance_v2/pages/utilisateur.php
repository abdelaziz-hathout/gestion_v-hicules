
<?php

 require_once("identifier.php");
require_once('connexiondb.php');
$req="SELECT * from users order by id desc";

$size=isset($_GET['size'] ) ?$_GET['size']: 10;    
  $page=isset($_GET['page'] ) ?$_GET['page']: 1;
  $offset= ($page-1)*$size ; 

$loginU=strtoupper(isset($_GET['loginU'])?$_GET['loginU']:"");

$type=isset($_POST['type'])?$_POST['type']:"all";

	$req="SELECT * from users where UPPER(email) like '$loginU%'
	order by id desc limit $size 
      offset $offset";
	$reqCount="SELECT count(*) countU from users where UPPER(email) like '$loginU%'";

$res=mysqli_query($conn,$req);
$reqCount=mysqli_query($conn,$reqCount);
$tabCount=mysqli_fetch_assoc($reqCount);
$nbrUsers=$tabCount['countU'];
  $rest= $nbrUsers%$size;   
         if($rest===0)
          $nbrPage=$nbrUsers / $size;
          else
          $nbrPage= floor($nbrUsers / $size) +1; 
        
?>

<!DOCTYPE html>
<html>
<head>
	<title>utilisateur</title>
	<?php require("styleLinks.php");?>
</head>
<body>
	<?php
     include("header.php");
	?>
<div class="container col-lg-6 col-lg-offset-3 col-md-10 col-md-offset-1 col-sm-12">
	<div class="util" >
	<div class="card">
		<div class="card-header bg-success text-white">Rechercher des uttilisateurs...</div>
	    <div class="card-body text-info bg-light">
	    	
	    	 <form method="post" action="utilisateur.php" class="form-inline">

	    	 	<div id="user"class="form-group" id="ch">
	    	 		
	    	 	<input type="text" class="form-control" name="loginU" placeholder="login or email" id="loginU" autocomplete="off"  value="<?php echo $loginU?>" >
	    	 	 <lable for="type1">&nbsp Type:&nbsp </lable>
	    	 	<select name="type" id="type1"class="form-control" id="type1" >
	    	 		<option value="all" <?php if($type=="all") echo "selected" ?> >All</option>
	    	 		<option value="1" <?php if($type=="1") echo "selected" ?>>Admin</option>
	    	 		<option value="0" <?php if($type=="0") echo "selected" ?>>User</option>
	    	 	</select>
	    	 	<?php  if($_SESSION['type']==1)  {?>
	    	 	<a href="newUser.php">&nbspAjouter un utilisateur <i class="fa fa-plus"></i></a>
	    	 	</div>
	    	    <?php  } ?>
	    	 </form>
	    </div>
	</div>

	<div class="card">
		<div class="card-header bg-primary text-white" id="nbr">
		List des uttilisateurs (<?php echo $nbrUsers ?> utilisateurs)</div>
	    <div  class="card-body text-info bg-light">
	    	 <div id="us2">
	    	<table  class="table table-striped table-bordered table-responsive tb" >
	    		<thead>
	    			<tr>
	    				<th>Id [<?php echo $nbrUsers ?>]</th>
	    				<th>login</th>
	    				<th>email</th>
	    				<th>type</th>
	    				<?php if(isset($_SESSION['type'])){
	    					if($_SESSION['type']==1){ ?>
	    				<th>Actions</th>
	    			<?php }} ?>
	    			</tr>
	    		</thead>
	    		<tbody >
	    			<?php
	    			while($user=mysqli_fetch_assoc($res)){
	    				?>
	    			<tr class="bg-<?php echo $user['etat']==1 ? 'success':'danger' ?> text-white">
	    				<td><?php echo $user["id"] ?></td>
	    				<td><?php echo $user["login"] ?></td>
	    				<td><?php echo $user["email"] ?></td>
	    				<td><?php echo $user["type"]==1?'admin':'user'; ?></td>
	    				<?php if(isset($_SESSION['type'])){
	    					if($_SESSION['type']==1){ ?>

	    				<td id="act">
	    					
	    					<?php  if($_SESSION['id']!=$user['id']){ ?>
	    						<a  href="editUser.php?id=<?php echo $user['id'] ?>" title="edit user">
	    						<i class="fa fa-edit"></i>
	    					</a>&nbsp &nbsp
	    				 <a onclick="return confirm('etes sur de vouloir supprimer le user ')" href="deleteUser.php?id=<?php echo $user['id']?>" title="delete user">
	    				<i class="fa fa-trash"></i>
	    				</a>
	    				&nbsp &nbsp
                         
	    				<a  href="activerUser.php?id=<?php echo $user["id"] ?>&etat=<?php echo $user["etat"]?>" >
	    						<?php if($user['etat']==1 ) echo ' <i class="fa fa-check-circle active"></i'; 
	    						 else echo '
	    							<i class="fa fa-ban active"></i>
	    						' ;?>
	    					</a>
	    					<?php } ?>
	    			</td>
	    		
	    		   <?php }} ?>
	    			</tr>
	    			<?php }?>
	    		</tbody>
	    	</table>
	    	</div>
              <div >
                       <ul class="pagination ">
                        <?php
                        for($i=1;$i<=$nbrPage;$i++){ ?>
                          
                         <li class="<?php if($i == $page) echo'active' ?> page-item"> <a  class="page-link"href="utilisateur.php?page=<?php echo $i;?>">  <?php echo $i;?>  </a> </li> 

                       <?php   } ?>
                                          


                   
                        </ul>
                    </div>
            <a href="javaScript:history.back()" id="rt">retour </a>
	    </div>
	</div>
	</div>
</div>


<?php
include 'footer.php';
?>
</body>
</html>
