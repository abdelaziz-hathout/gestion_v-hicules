<?php
 require_once("identifier.php");


require_once('connexiondb.php');
 $id=isset($_GET['id'])?$_GET['id']:0;
 $idA=isset($_GET['idA'])?$_GET['idA']:0; 
 $nF=isset($_GET['nF'])?$_GET['nF']:0;
 $idF=$id;
$req1="SELECT * from affaires where id='$idA'";
$res1=mysqli_query($conn,$req1);
$aff=mysqli_fetch_assoc($res1);
$nbrF=$nF-1;
if($nbrF>0){
$req3="DELETE from fractions where affaire='$idA'";
$res3=mysqli_query($conn,$req3);

$soldeA=$aff['solde'];
$datei=$aff['datei'];
$duree=$aff['duree'];

 $a=$duree/$nbrF;
    $a=floor($a*30);
    for($x=1,$n=0;$x<=$nbrF;$x++,$n+=$a){

      $montant = $soldeA/$nbrF;
      $dat=$datei."+".$n." days";
      $date_effet=date('Y-m-d',strtotime($dat));
      $date_reg=$date_effet;
      $requete="insert into fractions (affaire,montant,date_effet,date_reg,solde)
      values ($idA,'$montant','$date_effet','$date_reg','$montant')";

      $resultat=mysqli_query($conn,$requete);
    }

    $req4="UPDATE affaires  set nbrFractions='$nbrF' where id='$idA'";
    $res4=mysqli_query($conn,$req4);
    
    if($res4)
    	echo 'success';
    else echo mysqli_error($conn);
}
else echo 'impossible de supprimer la fraction!';

echo '<script> setTimeout(function(){window.location.href="reglerAffaire.php?id='.$idA.'";  },1200); </script>';


?>